﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CargoManagement_Exceptions
{
    public class InvalidUserException : ApplicationException
    {
        //Default constructor
        public InvalidUserException() : base()
        {

        }

        //Parameterized constructor with message parameter
        public InvalidUserException(string message) : base(message)
        {

        }
    }
}
