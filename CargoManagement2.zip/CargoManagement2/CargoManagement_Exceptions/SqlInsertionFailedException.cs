﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CargoManagement_Exceptions
{
    public class SqlInsertionFailedException : ApplicationException
    {
        //Default constructor
        public SqlInsertionFailedException() : base()
        {

        }

        //Parameterized constructor with message parameter
        public SqlInsertionFailedException(string message) : base(message)
        {

        }
    }
}
