﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using CargoManagement_Entities;
using CargoManagement_Exceptions;
using System.Data.SqlClient;

namespace CargoManagement_DAL
{
    public class CancelRequest_DAL
    {
        //Function to insert CancelRequest record in database
        public static int Insert(CancelRequest canceldet)
        {
            int recordsAffected = 0;
            SqlCommand cmd = null;

            try
            {
                //Creating command object
                cmd = DataConnection.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "usp_InsertCancelRequest";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@CancelRequestID", canceldet.CancelRequestID);
                cmd.Parameters.AddWithValue("@CustomerID", canceldet.CustomerID);
                cmd.Parameters.AddWithValue("@CancelRequestReason", canceldet.CancelRequestReason);
                cmd.Parameters.AddWithValue("@Date", canceldet.Date);

                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                cmd.Connection.Close();
            }

            return recordsAffected;
        }

        //Function to update CancelRequest record in database
        public static int Update(CancelRequest canceldet)
        {
            int recordsAffected = 0;
            SqlCommand cmd = null;

            try
            {
                //Creating command object
                cmd = DataConnection.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "usp_UpdateCancelRequest";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@CancelRequestID", canceldet.CancelRequestID);
                cmd.Parameters.AddWithValue("@CustomerID", canceldet.CustomerID);
                cmd.Parameters.AddWithValue("@CancelRequestReason", canceldet.CancelRequestReason);
                cmd.Parameters.AddWithValue("@Date", canceldet.Date);

                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                cmd.Connection.Close();
            }
            return recordsAffected;
        }

        //Function to delete CancelRequest record from database
        public static int Delete(int id)
        {
            int recordsAffected = 0;
            SqlCommand cmd = null;
            try
            {
                //Creating command object
                cmd = DataConnection.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "usp_DeleteCancelRequest";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@CancelRequestID", id);

                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                cmd.Connection.Close();
            }
            return recordsAffected;
        }

        //Function to search CancelRequest record based on id
        public static CancelRequest SearchByID(int id)
        {
            CancelRequest canceldet = null;
            SqlCommand cmd = null;
            SqlDataReader dr = null;
            try
            {
                cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "usp_SearchCancelRequests";
                cmd.Parameters.AddWithValue("@AdminID", id);

                cmd.Connection.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    canceldet = new CancelRequest();
                    dr.Read();
                    canceldet.CancelRequestID = (int)dr["CancelRequestID"];
                    canceldet.CustomerID = (int)dr["CustomerID"];
                    canceldet.CancelRequestReason = dr["CancelRequestReason"].ToString();
                    canceldet.Date = (DateTime)dr["Date"];
                }
                else
                {
                    throw new UserNotFoundException("Record not found");
                }

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                cmd.Connection.Close();
            }
            return canceldet;
        }

        //Function to retrieve all CancelRequest record
        public static List<CancelRequest> SelectAll()
        {
            List<CancelRequest> canceldetList = null;
            SqlCommand cmd = null;
            SqlDataReader dr = null;

            try
            {
                cmd = DataConnection.GenerateCommand();
                cmd.CommandText = "usp_DisplayCancelRequest";

                cmd.Connection.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    canceldetList = new List<CancelRequest>();
                    while (dr.Read())
                    {
                        CancelRequest canceldet = new CancelRequest();

                        canceldet.CancelRequestID = (int)dr["CancelRequestID"];
                        canceldet.CustomerID = (int)dr["CustomerID"];
                        canceldet.CancelRequestReason = dr["CancelRequestReason"].ToString();
                        canceldet.Date = (DateTime)dr["Date"];
                        canceldetList.Add(canceldet);
                    }
                }
                else
                    throw new UserNotFoundException("Record not available");

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                cmd.Connection.Close();
            }
            return canceldetList;
        }
    }
}
