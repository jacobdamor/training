﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using CargoManagement_Entities;
using CargoManagement_Exceptions;
using System.Data.SqlClient;

namespace CargoManagement_DAL
{
    public class ProductDetail_DAL
    {
        public static int Insert(ProductDetail pdr)
        {
            int recordsAffected = 0;
            SqlCommand cmd = null;

            try
            {
                //Creating command object
                cmd = DataConnection.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "usp_InsertProductDetail";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@ProdID", pdr.ProdID);
                cmd.Parameters.AddWithValue("@Destination", pdr.ProdName);
                cmd.Parameters.AddWithValue("@Price", pdr.TypeID);


                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                cmd.Connection.Close();
            }

            return recordsAffected;
        }

        public static int Update(ProductDetail pdr)
        {
            int recordsAffected = 0;
            SqlCommand cmd = null;

            try
            {
                //Creating command object
                cmd = DataConnection.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "usp_UpdateProductDetail";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@ProdID", pdr.ProdID);
                cmd.Parameters.AddWithValue("@Destination", pdr.ProdName);
                cmd.Parameters.AddWithValue("@Price", pdr.TypeID);

                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                cmd.Connection.Close();
            }
            return recordsAffected;
        }

        //Function to delete student record from database
        public static int Delete(int id)
        {
            int recordsAffected = 0;
            SqlCommand cmd = null;
            try
            {
                //Creating command object
                cmd = DataConnection.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "usp_DeleteProductDetail";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@ProdID", id);


                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                cmd.Connection.Close();
            }
            return recordsAffected;
        }

        //Function to search student record based on Student Code
        public static ProductDetail SearchByID(int id)
        {
            ProductDetail pdr = null;
            SqlCommand cmd = null;
            SqlDataReader dr = null;
            try
            {
                cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "usp_SearchProductDetail";

                cmd.Parameters.AddWithValue("@ProdID", id);

                cmd.Connection.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    pdr = new ProductDetail();
                    dr.Read();

                    pdr.ProdID = (int)dr["ProdID"];
                    pdr.ProdName = dr["ProdName"].ToString();
                    pdr.TypeID = (int)dr["TypeID"];

                }
                else
                {
                    throw new UserNotFoundException("Record not found");
                }

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                cmd.Connection.Close();
            }
            return pdr;
        }

        //Function to retrieve all student record
        public static List<ProductDetail> SelectAll()
        {
            List<ProductDetail> pdrList = null;
            SqlCommand cmd = null;
            SqlDataReader dr = null;

            try
            {
                cmd = DataConnection.GenerateCommand();
                cmd.CommandText = "usp_DisplayProductDetail";

                cmd.Connection.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    pdrList = new List<ProductDetail>();
                    while (dr.Read())
                    {
                        ProductDetail pdr = new ProductDetail();

                        pdr.ProdID = (int)dr["ProdID"];
                        pdr.ProdName = dr["ProdName"].ToString();
                        pdr.TypeID = (int)dr["TypeID"];
                        pdrList.Add(pdr);
                    }
                }
                else
                    throw new UserNotFoundException("Record not available");

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                cmd.Connection.Close();
            }
            return pdrList;
        }
    }
}
