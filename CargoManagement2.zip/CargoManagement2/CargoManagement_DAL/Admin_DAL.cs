﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using CargoManagement_Entities;
using CargoManagement_Exceptions;
using System.Data.SqlClient;

namespace CargoManagement_DAL
{
    public class Admin_DAL
    {
        //Function to insert Admin record in database
        public static int Insert(AdminDetail admindet)
        {
            int recordsAffected = 0;
            SqlCommand cmd = null;

            try
            {
                //Creating command object
                cmd = DataConnection.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "usp_InsertAdminDetails";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@AdminID", admindet.AdminID);
                cmd.Parameters.AddWithValue("@Name", admindet.Name);
                cmd.Parameters.AddWithValue("@Address", admindet.Address);
                cmd.Parameters.AddWithValue("@City", admindet.City);

                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                cmd.Connection.Close();
            }

            return recordsAffected;
        }

        //Function to Update Admin record in database
        public static int Update(AdminDetail admindet)
        {
            int recordsAffected = 0;
            SqlCommand cmd = null;

            try
            {
                //Creating command object
                cmd = DataConnection.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "usp_UpdateAdminDetails";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@AdminID", admindet.AdminID);
                cmd.Parameters.AddWithValue("@Name", admindet.Name);
                cmd.Parameters.AddWithValue("@Address", admindet.Address);
                cmd.Parameters.AddWithValue("@City", admindet.City);

                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                cmd.Connection.Close();
            }
            return recordsAffected;
        }

        //Function to delete Admin record from database
        public static int Delete(int id)
        {
            int recordsAffected = 0;
            SqlCommand cmd = null;
            try
            {
                //Creating command object
                cmd = DataConnection.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "usp_DeleteAdminDetails";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@AdminID", id);

                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                cmd.Connection.Close();
            }
            return recordsAffected;
        }

        //Function to search Admin record based on Admin ID
        public static AdminDetail SearchByID(int id)
        {
            AdminDetail admindet = null;
            SqlCommand cmd = null;
            SqlDataReader dr = null;
            try
            {
                cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "usp_SearchAdminDetails";
                cmd.Parameters.AddWithValue("@AdminID", id);

                cmd.Connection.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    admindet = new AdminDetail();
                    dr.Read();
                    admindet.AdminID = (int)dr["AdminID"];
                    admindet.Name = dr["Name"].ToString();
                    admindet.City = dr["City"].ToString();
                    admindet.Address = dr["Address"].ToString();
                }
                else
                {
                    throw new UserNotFoundException("Record not found");
                }

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                cmd.Connection.Close();
            }
            return admindet;
        }

        //Function to retrieve all Admin record
        public static List<AdminDetail> SelectAll()
        {
            List<AdminDetail> admindetList = null;
            SqlCommand cmd = null;
            SqlDataReader dr = null;

            try
            {
                cmd = DataConnection.GenerateCommand();
                cmd.CommandText = "usp_DisplayAdminDetails";

                cmd.Connection.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    admindetList = new List<AdminDetail>();
                    while (dr.Read())
                    {
                        AdminDetail admindet = new AdminDetail();

                        admindet.AdminID = (int)dr["AdminID"];
                        admindet.Name = dr["Name"].ToString();
                        admindet.City = dr["City"].ToString();
                        admindet.Address = dr["Address"].ToString();
                        admindetList.Add(admindet);
                    }
                }
                else
                    throw new UserNotFoundException("Record not available");

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                cmd.Connection.Close();
            }
            return admindetList;
        }
    }
}
