﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using CargoManagement_Entities;
using CargoManagement_Exceptions;
using System.Data.SqlClient;

namespace CargoManagement_DAL
{
    public class Employee_DAL
    {
        //Function to insert Employee record in database
        public static int Insert(EmployeeDetail empdet)
        {
            int recordsAffected = 0;
            SqlCommand cmd = null;

            try
            {
                //Creating command object
                cmd = DataConnection.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "usp_InsertEmployeeDetails";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@EmployeeID", empdet.EmployeeID);
                cmd.Parameters.AddWithValue("@Name", empdet.Name);
                cmd.Parameters.AddWithValue("@Address", empdet.Address);
                cmd.Parameters.AddWithValue("@City", empdet.City);

                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                cmd.Connection.Close();
            }

            return recordsAffected;
        }

        //Function to update Employee record in database
        public static int Update(EmployeeDetail empdet)
        {
            int recordsAffected = 0;
            SqlCommand cmd = null;

            try
            {
                //Creating command object
                cmd = DataConnection.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "usp_UpdateEmployeeDetails";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@EmployeeID", empdet.EmployeeID);
                cmd.Parameters.AddWithValue("@Name", empdet.Name);
                cmd.Parameters.AddWithValue("@Address", empdet.Address);
                cmd.Parameters.AddWithValue("@City", empdet.City);

                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                cmd.Connection.Close();
            }
            return recordsAffected;
        }

        //Function to delete Employee record from database
        public static int Delete(int id)
        {
            int recordsAffected = 0;
            SqlCommand cmd = null;
            try
            {
                //Creating command object
                cmd = DataConnection.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "usp_DeleteEmployeeDetails";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@EmployeeID", id);

                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                cmd.Connection.Close();
            }
            return recordsAffected;
        }

        //Function to search Employee record based on id
        public static EmployeeDetail SearchByID(int id)
        {
            EmployeeDetail empdet = null;
            SqlCommand cmd = null;
            SqlDataReader dr = null;
            try
            {
                cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "usp_SearchEmployeeDetails";
                cmd.Parameters.AddWithValue("@EmployeeID", id);

                cmd.Connection.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    empdet = new EmployeeDetail();
                    dr.Read();
                    empdet.EmployeeID = (int)dr["EmployeeID"];
                    empdet.Name = dr["Name"].ToString();
                    empdet.City = dr["City"].ToString();
                    empdet.Address = dr["Address"].ToString();
                }
                else
                {
                    throw new UserNotFoundException("Record not found");
                }

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                cmd.Connection.Close();
            }
            return empdet;
        }

        //Function to retrieve all Employee record
        public static List<EmployeeDetail> SelectAll()
        {
            List<EmployeeDetail> empdetList = null;
            SqlCommand cmd = null;
            SqlDataReader dr = null;

            try
            {
                cmd = DataConnection.GenerateCommand();
                cmd.CommandText = "usp_DisplayEmployeeDetails";

                cmd.Connection.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    empdetList = new List<EmployeeDetail>();
                    while (dr.Read())
                    {
                        EmployeeDetail custdet = new EmployeeDetail();

                        custdet.EmployeeID = (int)dr["EmployeeID"];
                        custdet.Name = dr["Name"].ToString();
                        custdet.City = dr["City"].ToString();
                        custdet.Address = dr["Address"].ToString();
                        empdetList.Add(custdet);
                    }
                }
                else
                    throw new UserNotFoundException("Record not available");

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                cmd.Connection.Close();
            }
            return empdetList;
        }
    }
}
