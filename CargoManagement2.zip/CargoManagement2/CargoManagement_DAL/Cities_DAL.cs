﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using CargoManagement_Entities;
using CargoManagement_Exceptions;
using System.Data.SqlClient;

namespace CargoManagement_DAL
{
    public class Cities_DAL
    {
        //Function to insert Employee record in database
        public static int Insert(City citydet)
        {
            int recordsAffected = 0;
            SqlCommand cmd = null;

            try
            {
                //Creating command object
                cmd = DataConnection.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "usp_InsertCities";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@CityName", citydet.CityName);
                cmd.Parameters.AddWithValue("@State", citydet.State);

                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                cmd.Connection.Close();
            }

            return recordsAffected;
        }

        //Function to update Employee record in database
        public static int Update(City citydet)
        {
            int recordsAffected = 0;
            SqlCommand cmd = null;

            try
            {
                //Creating command object
                cmd = DataConnection.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "usp_UpdateCities";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@CityName", citydet.CityName);
                cmd.Parameters.AddWithValue("@State", citydet.State);

                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                cmd.Connection.Close();
            }
            return recordsAffected;
        }

        //Function to delete Employee record from database
        public static int Delete(string cityname)
        {
            int recordsAffected = 0;
            SqlCommand cmd = null;
            try
            {
                //Creating command object
                cmd = DataConnection.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "usp_DeleteCities";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@CityName", cityname);

                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                cmd.Connection.Close();
            }
            return recordsAffected;
        }

        //Function to search Employee record based on CityName
        public static City SearchByName(string cityname)
        {
            City citydet = null;
            SqlCommand cmd = null;
            SqlDataReader dr = null;
            try
            {
                cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "usp_SearchCities";
                cmd.Parameters.AddWithValue("@CityName", cityname);

                cmd.Connection.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    citydet = new City();
                    dr.Read();
                    citydet.CityName = dr["CityName"].ToString();
                    citydet.State = dr["State"].ToString();
                }
                else
                {
                    throw new UserNotFoundException("Record not found");
                }

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                cmd.Connection.Close();
            }
            return citydet;
        }

        //Function to retrieve all Employee record
        public static List<City> SelectAll()
        {
            List<City> citydetList = null;
            SqlCommand cmd = null;
            SqlDataReader dr = null;

            try
            {
                cmd = DataConnection.GenerateCommand();
                cmd.CommandText = "usp_DisplayCitiess";

                cmd.Connection.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    citydetList = new List<City>();
                    while (dr.Read())
                    {
                        City citydet = new City();

                        citydet.CityName = dr["CityName"].ToString();
                        citydet.State = dr["State"].ToString();
                        citydetList.Add(citydet);
                    }
                }
                else
                    throw new UserNotFoundException("Record not available");

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                cmd.Connection.Close();
            }
            return citydetList;
        }
    }
}
