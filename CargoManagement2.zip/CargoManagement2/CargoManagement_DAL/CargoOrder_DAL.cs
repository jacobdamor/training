﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using CargoManagement_Entities;
using CargoManagement_Exceptions;
using System.Data.SqlClient;

namespace CargoManagement_DAL
{
    public class CargoOrder_DAL
    {
        //Function to insert CargoOrder record in database
        public static int Insert(CargoOrder orderdet)
        {
            int recordsAffected = 0;
            SqlCommand cmd = null;

            try
            {
                //Creating command object
                cmd = DataConnection.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "usp_InsertCargoOrder";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@OrderID", orderdet.OrderID);
                cmd.Parameters.AddWithValue("@OrderDate", orderdet.OrderDate);
                cmd.Parameters.AddWithValue("@DeleveryDate", orderdet.DeleveryDate);
                cmd.Parameters.AddWithValue("@OrderPaymentID", orderdet.OrderPaymentID);
                cmd.Parameters.AddWithValue("@EmployeeID", orderdet.EmployeeID);
                cmd.Parameters.AddWithValue("@CustomerID", orderdet.CustomerID);


                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                cmd.Connection.Close();
            }

            return recordsAffected;
        }

        //Function to update CargoOrder record in database
        public static int Update(CargoOrder orderdet)
        {
            int recordsAffected = 0;
            SqlCommand cmd = null;

            try
            {
                //Creating command object
                cmd = DataConnection.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "usp_UpdateCargoOrder";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@OrderID", orderdet.OrderID);
                cmd.Parameters.AddWithValue("@OrderDate", orderdet.OrderDate);
                cmd.Parameters.AddWithValue("@DeleveryDate", orderdet.DeleveryDate);
                cmd.Parameters.AddWithValue("@OrderPaymentID", orderdet.OrderPaymentID);
                cmd.Parameters.AddWithValue("@EmployeeID", orderdet.EmployeeID);
                cmd.Parameters.AddWithValue("@CustomerID", orderdet.CustomerID);

                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                cmd.Connection.Close();
            }
            return recordsAffected;
        }

        //Function to delete CargoOrder record from database
        public static int Delete(int id)
        {
            int recordsAffected = 0;
            SqlCommand cmd = null;
            try
            {
                //Creating command object
                cmd = DataConnection.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "usp_DeleteCargoOrder";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@OrderID", id);

                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                cmd.Connection.Close();
            }
            return recordsAffected;
        }

        //Function to search CargoOrder record based on Student Code
        public static CargoOrder SearchByID(int id)
        {
            CargoOrder orderdet = null;
            SqlCommand cmd = null;
            SqlDataReader dr = null;
            try
            {
                cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "usp_SearchCargoOrder";
                cmd.Parameters.AddWithValue("@OrderID", id);

                cmd.Connection.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    orderdet = new CargoOrder();
                    dr.Read();
                    orderdet.OrderID = (int)dr["OrderID"];
                    orderdet.OrderDate = (DateTime)dr["OrderDate"];
                    orderdet.DeleveryDate = (DateTime)dr["DeleveryDate"];
                    orderdet.OrderPaymentID = (int)dr["OrderPaymentID"];
                    orderdet.CustomerID = (int)dr["CustomerID"];
                    orderdet.EmployeeID = (int)dr["EmployeeID"];

                }
                else
                {
                    throw new UserNotFoundException("Record not found");
                }

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                cmd.Connection.Close();
            }
            return orderdet;
        }

        //Function to retrieve all CargoOrder record
        public static List<CargoOrder> SelectAll()
        {
            List<CargoOrder> OrderList = null;
            SqlCommand cmd = null;
            SqlDataReader dr = null;

            try
            {
                cmd = DataConnection.GenerateCommand();
                cmd.CommandText = "usp_DisplayCargoOrder";

                cmd.Connection.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    OrderList = new List<CargoOrder>();
                    while (dr.Read())
                    {
                        CargoOrder orderdet = new CargoOrder();

                        orderdet.OrderID = (int)dr["OrderID"];
                        orderdet.OrderDate = (DateTime)dr["OrderDate"];
                        orderdet.DeleveryDate = (DateTime)dr["DeleveryDate"];
                        orderdet.OrderPaymentID = (int)dr["OrderPaymentID"];
                        orderdet.CustomerID = (int)dr["CustomerID"];
                        orderdet.EmployeeID = (int)dr["EmployeeID"];
                        OrderList.Add(orderdet);
                    }
                }
                else
                    throw new UserNotFoundException("Record not available");

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                cmd.Connection.Close();
            }
            return OrderList;
        }
    }
}
