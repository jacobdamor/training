﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using CargoManagement_Entities;
using CargoManagement_Exceptions;

namespace CargoManagement_DAL
{
    public class Register_DAL
    {
        //Function to insert registered record from database
        public static int Insert(Register reg1)
        {
            int resId = 0;
            SqlCommand cmd = null;

            try
            {
                //Creating command object
                cmd = DataConnection.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "usp_InsertRegister";

                //Adding input parameters to command
                cmd.Parameters.AddWithValue("@UserName", reg1.UserName);
                cmd.Parameters.AddWithValue("@Password", reg1.Password);
                cmd.Parameters.AddWithValue("@UserType", reg1.UserType);
                cmd.Parameters.AddWithValue("@PhoneNo", reg1.PhoneNo);
                cmd.Parameters.AddWithValue("@EmailId", reg1.EmailId);

                //Adding output parameters to command
                SqlParameter output = new SqlParameter("@ResID", SqlDbType.Int);
                output.Direction = ParameterDirection.Output;
                cmd.Parameters.Add(output);

                //Executing command
                cmd.Connection.Open();
                if(cmd.ExecuteNonQuery() != 1)
                    throw new SqlInsertionFailedException();
                else
                    resId = Convert.ToInt32(output.Value);
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                cmd.Connection.Close();
            }

            return resId;
        }

        //Function to Update registered record from database
        public static int Update(Register reg1)
        {
            int recordsAffected = 0;
            SqlCommand cmd = null;

            try
            {
                //Creating command object
                cmd = DataConnection.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "usp_UpdateRegister";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@RegisterID", reg1.RegisterID);
                cmd.Parameters.AddWithValue("@UserName", reg1.UserName);
                cmd.Parameters.AddWithValue("@Password", reg1.Password);
                cmd.Parameters.AddWithValue("@UserType", reg1.UserType);
                cmd.Parameters.AddWithValue("@PhoneNo", reg1.PhoneNo);
                cmd.Parameters.AddWithValue("@EmailId", reg1.EmailId);

                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                cmd.Connection.Close();
            }
            return recordsAffected;
        }

        //Function to delete registered record from database
        public static int Delete(int id)
        {
            int recordsAffected = 0;
            SqlCommand cmd = null;
            try
            {
                //Creating command object
                cmd = DataConnection.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "usp_DeleteRegister";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@RegisterID", id);

                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                cmd.Connection.Close();
            }
            return recordsAffected;
        }

        //Function to match login credentials record based on  username, password, usertype
        public static Register matchCredentials(string username, string password, string usertype)
        {
            Register reg1 = null;
            SqlCommand cmd = null;
            SqlDataReader dr = null;
            try
            {
                cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "usp_MatchRegister";
                cmd.Parameters.AddWithValue("@UserName", username);
                cmd.Parameters.AddWithValue("@Password", password);
                cmd.Parameters.AddWithValue("@UserType", usertype);

                cmd.Connection.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    reg1 = new Register();
                    dr.Read();
                    reg1.RegisterID = (int)dr["RegisterID"];
                    reg1.UserName = dr["UserName"].ToString();
                    reg1.Password = dr["Password"].ToString();
                    reg1.UserType = dr["UserType"].ToString();
                    reg1.PhoneNo = dr["PhoneNo"].ToString();
                    reg1.EmailId = dr["EmailId"].ToString();
                }
                else
                {
                    throw new UserNotFoundException("Record not found");
                }

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                cmd.Connection.Close();
            }
            return reg1;
        }

        //Function to retrieve all registered record
        public static List<Register> SelectAll()
        {
            List<Register> regList = null;
            SqlCommand cmd = null;
            SqlDataReader dr = null;

            try
            {
                cmd = DataConnection.GenerateCommand();
                cmd.CommandText = "usp_DisplayRegister";

                cmd.Connection.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    regList = new List<Register>();
                    while (dr.Read())
                    {
                        Register reg1 = new Register();

                        reg1.RegisterID = (int)dr["RegisterID"];
                        reg1.UserName = dr["UserName"].ToString();
                        reg1.Password = dr["Password"].ToString();
                        reg1.UserType = dr["UserType"].ToString();
                        reg1.PhoneNo = dr["PhoneNo"].ToString();
                        reg1.EmailId = dr["EmailId"].ToString();
                        regList.Add(reg1);
                    }
                }
                else
                    throw new UserNotFoundException("Record not available");

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                cmd.Connection.Close();
            }
            return regList;
        }

        //Function to search registered record based on ID
        public static Register SearchByID(int id)
        {
            Register reg1 = null;
            SqlCommand cmd = null;
            SqlDataReader dr = null;
            try
            {
                cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "usp_SearchRegister";
                cmd.Parameters.AddWithValue("@RegisterID", id);

                cmd.Connection.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    reg1 = new Register();
                    dr.Read();
                    reg1.RegisterID = (int)dr["RegisterID"];
                    reg1.UserName = dr["UserName"].ToString();
                    reg1.Password = dr["Password"].ToString();
                    reg1.UserType = dr["UserType"].ToString();
                    reg1.PhoneNo = dr["PhoneNo"].ToString();
                    reg1.EmailId = dr["EmailId"].ToString();
                }
                else
                {
                    throw new UserNotFoundException("Record not found");
                }

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                cmd.Connection.Close();
            }
            return reg1;
        }
    }
}
