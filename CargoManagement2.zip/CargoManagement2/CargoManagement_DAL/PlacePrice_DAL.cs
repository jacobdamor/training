﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using CargoManagement_Entities;
using System.Data.SqlClient;
using CargoManagement_Exceptions;

namespace CargoManagement_DAL
{
    public class PlacePrice_DAL
    {
        public static int Insert(PlacePrice plr)
        {
            int recordsAffected = 0;
            SqlCommand cmd = null;

            try
            {
                //Creating command object
                cmd = DataConnection.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "usp_InsertPlacePrice";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@Source", plr.Source);
                cmd.Parameters.AddWithValue("@Destination", plr.Destination);
                cmd.Parameters.AddWithValue("@Price", plr.Price);


                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                cmd.Connection.Close();
            }

            return recordsAffected;
        }

        public static int Update(PlacePrice plr)
        {
            int recordsAffected = 0;
            SqlCommand cmd = null;

            try
            {
                //Creating command object
                cmd = DataConnection.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "usp_UpdatePlacePrice";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@Source", plr.Source);
                cmd.Parameters.AddWithValue("@Destination", plr.Destination);
                cmd.Parameters.AddWithValue("@Price", plr.Price);

                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                cmd.Connection.Close();
            }
            return recordsAffected;
        }

        //Function to delete student record from database
        public static int Delete(string source, string destination)
        {
            int recordsAffected = 0;
            SqlCommand cmd = null;
            try
            {
                //Creating command object
                cmd = DataConnection.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "usp_DeletePlacePrice";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@Source", source);
                cmd.Parameters.AddWithValue("@Destination", destination);

                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                cmd.Connection.Close();
            }
            return recordsAffected;
        }

        //Function to search student record based on Student Code
        public static PlacePrice SearchByID(string source, string destination)
        {
            PlacePrice plr = null;
            SqlCommand cmd = null;
            SqlDataReader dr = null;
            try
            {
                cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "usp_SearchPlacePrice";
                cmd.Parameters.AddWithValue("@Source", source);
                cmd.Parameters.AddWithValue("@Destination", destination);

                cmd.Connection.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    plr = new PlacePrice();
                    dr.Read();

                    plr.Source = dr["Source"].ToString();
                    plr.Destination = dr["Destination"].ToString();
                    plr.Price = Convert.ToDecimal(dr["Price"]);

                }
                else
                {
                    throw new UserNotFoundException("Record not found");
                }

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                cmd.Connection.Close();
            }
            return plr;
        }

        //Function to retrieve all student record
        public static List<PlacePrice> SelectAll()
        {
            List<PlacePrice> plrList = null;
            SqlCommand cmd = null;
            SqlDataReader dr = null;

            try
            {
                cmd = DataConnection.GenerateCommand();
                cmd.CommandText = "usp_DisplayPlacePrice";

                cmd.Connection.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    plrList = new List<PlacePrice>();
                    while (dr.Read())
                    {
                        PlacePrice plr = new PlacePrice();

                        plr.Source = dr["Source"].ToString();
                        plr.Destination = dr["Destination"].ToString();
                        plr.Price = Convert.ToDecimal(dr["Price"]);
                        plrList.Add(plr);
                    }
                }
                else
                    throw new UserNotFoundException("Record not available");

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                cmd.Connection.Close();
            }
            return plrList;
        }
    }
}

