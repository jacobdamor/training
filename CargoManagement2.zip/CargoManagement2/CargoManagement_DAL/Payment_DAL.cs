﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.SqlClient;
using CargoManagement_Entities;
using CargoManagement_Exceptions;

namespace CargoManagement_DAL
{
    public class Payment_DAL
    {
        //Function to insert payment record in database
        public static int Insert(Payment pay)
        {
            int recordsAffected = 0;
            SqlCommand cmd = null;

            try
            {
                //Creating command object
                cmd = DataConnection.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "usp_InsertCustomerDetails";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@PaymentID", pay.PaymentID);
                cmd.Parameters.AddWithValue("@PayAccName", pay.PayAccName);
                cmd.Parameters.AddWithValue("@PaymentDate", pay.PaymentDate);
                cmd.Parameters.AddWithValue("@PaymentMethod", pay.PaymentMethod);
                cmd.Parameters.AddWithValue("@PayOrderID", pay.PayOrderID);

                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                cmd.Connection.Close();
            }

            return recordsAffected;
        }

        //Function to update payment record in database
        public static int Update(Payment pay)
        {
            int recordsAffected = 0;
            SqlCommand cmd = null;

            try
            {
                //Creating command object
                cmd = DataConnection.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "usp_UpdatePayment";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@PaymentID", pay.PaymentID);
                cmd.Parameters.AddWithValue("@PayAccName", pay.PayAccName);
                cmd.Parameters.AddWithValue("@PaymentDate", pay.PaymentDate);
                cmd.Parameters.AddWithValue("@PaymentMethod", pay.PaymentMethod);
                cmd.Parameters.AddWithValue("@PayOrderID", pay.PayOrderID);

                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                cmd.Connection.Close();
            }
            return recordsAffected;
        }

        //Function to delete payment record from database
        public static int Delete(int id)
        {
            int recordsAffected = 0;
            SqlCommand cmd = null;
            try
            {
                //Creating command object
                cmd = DataConnection.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "usp_DeletePayment";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@PaymentID", id);

                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                cmd.Connection.Close();
            }
            return recordsAffected;
        }

        //Function to search payment record based on payment id
        public static Payment SearchByID(int id)
        {
            Payment pay = null;
            SqlCommand cmd = null;
            SqlDataReader dr = null;
            try
            {
                cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "usp_SearchPayment";
                cmd.Parameters.AddWithValue("@PaymentID", id);

                cmd.Connection.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    pay = new Payment();
                    dr.Read();
                    pay.PaymentID = (int)dr["PaymentID"];
                    pay.PayAccName = dr["PayAccName"].ToString();
                    pay.PaymentDate = Convert.ToDateTime(dr["PaymentDate"]);
                    pay.PaymentMethod = Convert.ToString(dr["PaymentMethod"]);
                    pay.PayOrderID = (int)dr["PayOrderID"];


                }
                else
                {
                    throw new UserNotFoundException("Record not found");
                }

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                cmd.Connection.Close();
            }
            return pay;
        }

        //Function to retrieve all payment record
        public static List<Payment> SelectAll()
        {
            List<Payment> payList = null;
            SqlCommand cmd = null;
            SqlDataReader dr = null;

            try
            {
                cmd = DataConnection.GenerateCommand();
                cmd.CommandText = "usp_DisplayPayment";

                cmd.Connection.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    payList = new List<Payment>();
                    while (dr.Read())
                    {
                        Payment pay = new Payment();

                        pay.PaymentID = (int)dr["PaymentID"];
                        pay.PayAccName = dr["PayAccName"].ToString();
                        pay.PaymentDate = Convert.ToDateTime(dr["PaymentDate"]);
                        pay.PaymentMethod = Convert.ToString(dr["PaymentMethod"]);
                        pay.PayOrderID = (int)dr["PayOrderID"];
                        payList.Add(pay);
                    }
                }
                else
                    throw new UserNotFoundException("Record not available");

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                cmd.Connection.Close();
            }
            return payList;
        }
    }

}
