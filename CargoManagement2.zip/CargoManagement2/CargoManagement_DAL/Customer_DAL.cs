﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using CargoManagement_Entities;
using CargoManagement_Exceptions;

namespace CargoManagement_DAL
{
    public class Customer_DAL
    {
        //Function to insert student record in database
        public static int Insert(CustomerDetail custdet)
        {
            int recordsAffected = 0;
            SqlCommand cmd = null;

            try
            {
                //Creating command object
                cmd = DataConnection.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "usp_InsertCustomerDetails";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@CustomerID", custdet.CustomerID);
                cmd.Parameters.AddWithValue("@Name", custdet.Name);
                cmd.Parameters.AddWithValue("@Address", custdet.Address);
                cmd.Parameters.AddWithValue("@City", custdet.City);

                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                cmd.Connection.Close();
            }

            return recordsAffected;
        }

        public static int Update(CustomerDetail cusdet)
        {
            int recordsAffected = 0;
            SqlCommand cmd =null;

            try
            {
                //Creating command object
                cmd = DataConnection.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "usp_UpdateCustomerDetails";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@CustomerID", cusdet.CustomerID);
                cmd.Parameters.AddWithValue("@Name", cusdet.Name);
                cmd.Parameters.AddWithValue("@Address", cusdet.Address);
                cmd.Parameters.AddWithValue("@City", cusdet.City);

                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                cmd.Connection.Close();
            }
            return recordsAffected;
        }

        //Function to delete student record from database
        public static int Delete(int id)
        {
            int recordsAffected = 0;
            SqlCommand cmd = null;
            try
            {
                //Creating command object
                cmd = DataConnection.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "usp_DeleteCustomerDetails";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@CustomerID", id);

                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                cmd.Connection.Close();
            }
            return recordsAffected;
        }

        //Function to search student record based on Student Code
        public static CustomerDetail SearchByID(int id)
        {
            CustomerDetail custdet = null;
            SqlCommand cmd = null;
            SqlDataReader dr = null;
            try
            {
                cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "usp_SearchCustomerDetails";
                cmd.Parameters.AddWithValue("@CustomerID", id);

                cmd.Connection.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    custdet = new CustomerDetail();
                    dr.Read();
                    custdet.CustomerID = (int)dr["CustomerID"];
                    custdet.Name = dr["Name"].ToString();
                    custdet.City = dr["City"].ToString();
                    custdet.Address = dr["Address"].ToString();
                }
                else
                {
                    throw new UserNotFoundException("Record not found");
                }
                
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                cmd.Connection.Close();
            }
            return custdet;
        }

        //Function to retrieve all student record
        public static List<CustomerDetail> SelectAll()
        {
            List<CustomerDetail> custdetList = null;
            SqlCommand cmd = null;
            SqlDataReader dr = null;

            try
            {
                cmd = DataConnection.GenerateCommand();
                cmd.CommandText = "usp_DisplayCustomerDetails";

                cmd.Connection.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    custdetList = new List<CustomerDetail>();
                    while (dr.Read())
                    {
                        CustomerDetail custdet = new CustomerDetail();

                        custdet.CustomerID = (int)dr["CustomerID"];
                        custdet.Name = dr["Name"].ToString();
                        custdet.City = dr["City"].ToString();
                        custdet.Address = dr["Address"].ToString();
                        custdetList.Add(custdet);
                    }
                }
                else
                    throw new UserNotFoundException("Record not available");
                
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                cmd.Connection.Close();
            }
            return custdetList;
        }
    }
}
