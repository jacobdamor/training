﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using CargoManagement_Entities;
using CargoManagement_Exceptions;
using System.Data.SqlClient;

namespace CargoManagement_DAL
{
    public class CargoOrderDetail_DAL
    {
        //Function to insert CargoOrderDetail record in database
        public static int Insert(CargoOrderDetail coddet)
        {
            int recordsAffected = 0;
            SqlCommand cmd = null;

            try
            {
                //Creating command object
                cmd = DataConnection.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "usp_InsertCargoOrderDetails";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@CargoOrderID", coddet.CargoOrderID);
                cmd.Parameters.AddWithValue("@ProdID", coddet.ProdID);
                cmd.Parameters.AddWithValue("@UnitPrice", coddet.UnitPrice);
                cmd.Parameters.AddWithValue("@Qty", coddet.Qty);
                cmd.Parameters.AddWithValue("@Discount", coddet.Discount);
                cmd.Parameters.AddWithValue("@PaymentID", coddet.PaymentID);
                cmd.Parameters.AddWithValue("@TotalAmount", coddet.TotalAmount);
                cmd.Parameters.AddWithValue("@Source", coddet.Source);
                cmd.Parameters.AddWithValue("@Destination", coddet.Destination);
                cmd.Parameters.AddWithValue("@DestinationAddr", coddet.DestinationAddr);
                cmd.Parameters.AddWithValue("@FlightNo", coddet.FlightNo);
                cmd.Parameters.AddWithValue("@Status", coddet.Status);

                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                cmd.Connection.Close();
            }

            return recordsAffected;
        }

        //Function to update CargoOrderDetail record in database
        public static int Update(CargoOrderDetail coddet)
        {
            int recordsAffected = 0;
            SqlCommand cmd = null;

            try
            {
                //Creating command object
                cmd = DataConnection.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "usp_UpdateCargoOrderDetails";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@CargoOrderID", coddet.CargoOrderID);
                cmd.Parameters.AddWithValue("@ProdID", coddet.ProdID);
                cmd.Parameters.AddWithValue("@UnitPrice", coddet.UnitPrice);
                cmd.Parameters.AddWithValue("@Qty", coddet.Qty);
                cmd.Parameters.AddWithValue("@Discount", coddet.Discount);
                cmd.Parameters.AddWithValue("@PaymentID", coddet.PaymentID);
                cmd.Parameters.AddWithValue("@TotalAmount", coddet.TotalAmount);
                cmd.Parameters.AddWithValue("@Source", coddet.Source);
                cmd.Parameters.AddWithValue("@Destination", coddet.Destination);
                cmd.Parameters.AddWithValue("@DestinationAddr", coddet.DestinationAddr);
                cmd.Parameters.AddWithValue("@FlightNo", coddet.FlightNo);
                cmd.Parameters.AddWithValue("@Status", coddet.Status);

                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                cmd.Connection.Close();
            }
            return recordsAffected;
        }

        //Function to delete CargoOrderDetail record from database
        public static int Delete(int id)
        {
            int recordsAffected = 0;
            SqlCommand cmd = null;
            try
            {
                //Creating command object
                cmd = DataConnection.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "usp_DeleteCargoOrderDetails";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@CargoID", id);

                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                cmd.Connection.Close();
            }
            return recordsAffected;
        }

        //Function to search CargoOrderDetail record based on Student Code
        public static CargoOrderDetail SearchByID(int id)
        {
            CargoOrderDetail coddet = null;
            SqlCommand cmd = null;
            SqlDataReader dr = null;
            try
            {
                cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "usp_SearchCargoOrderDetails";
                cmd.Parameters.AddWithValue("@EmployeeID", id);

                cmd.Connection.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    coddet = new CargoOrderDetail();
                    dr.Read();
                    coddet.CargoID = (int)dr["CargoID"];
                    coddet.CargoOrderID = (int)dr["CargoOrderID"];
                    coddet.ProdID = (int)dr["ProdID"];
                    coddet.UnitPrice = (decimal)dr["UnitPrice"];
                    coddet.Qty = (int)dr["Qty"];
                    coddet.Discount = (decimal)dr["Discount"];
                    coddet.PaymentID = (int)dr["PaymentID"];
                    coddet.TotalAmount = (int)dr["TotalAmount"];
                    coddet.Source = dr["Source"].ToString();
                    coddet.Destination = dr["Destination"].ToString();
                    coddet.DestinationAddr = dr["DestinationAddr"].ToString();
                    coddet.FlightNo = (int)dr["FlightNo"];
                    coddet.Status = dr["Status"].ToString();
                }
                else
                {
                    throw new UserNotFoundException("Record not found");
                }

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                cmd.Connection.Close();
            }
            return coddet;
        }

        //Function to retrieve all CargoOrderDetail record
        public static List<CargoOrderDetail> SelectAll()
        {
            List<CargoOrderDetail> coddetList = null;
            SqlCommand cmd = null;
            SqlDataReader dr = null;

            try
            {
                cmd = DataConnection.GenerateCommand();
                cmd.CommandText = "usp_DisplayCargoOrderDetails";

                cmd.Connection.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    coddetList = new List<CargoOrderDetail>();
                    while (dr.Read())
                    {
                        CargoOrderDetail coddet = new CargoOrderDetail();

                        coddet.CargoID = (int)dr["CargoID"];
                        coddet.CargoOrderID = (int)dr["CargoOrderID"];
                        coddet.ProdID = (int)dr["ProdID"];
                        coddet.UnitPrice = (decimal)dr["UnitPrice"];
                        coddet.Qty = (int)dr["Qty"];
                        coddet.Discount = (decimal)dr["Discount"];
                        coddet.PaymentID = (int)dr["PaymentID"];
                        coddet.TotalAmount = (int)dr["TotalAmount"];
                        coddet.Source = dr["Source"].ToString();
                        coddet.Destination = dr["Destination"].ToString();
                        coddet.DestinationAddr = dr["DestinationAddr"].ToString();
                        coddet.FlightNo = (int)dr["FlightNo"];
                        coddet.Status = dr["Status"].ToString();
                        coddetList.Add(coddet);
                    }
                }
                else
                    throw new UserNotFoundException("Record not available");

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                cmd.Connection.Close();
            }
            return coddetList;
        }
    }
}
