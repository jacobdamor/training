﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using CargoManagement_Entities;
using CargoManagement_Exceptions;
using System.Data.SqlClient;

namespace CargoManagement_DAL
{
    public class CargoPrice_DAL
    {
        //Function to insert CargoPrice record in database
        public static int Insert(CargoPrice cpricedet)
        {
            int recordsAffected = 0;
            SqlCommand cmd = null;

            try
            {
                //Creating command object
                cmd = DataConnection.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "usp_InsertCargoPrice";

                //Adding parameters to command

                cmd.Parameters.AddWithValue("@Weight", cpricedet.Weight);
                cmd.Parameters.AddWithValue("@Price", cpricedet.Price);

                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                cmd.Connection.Close();
            }

            return recordsAffected;
        }

        //Function to update CargoPrice record in database
        public static int Update(CargoPrice cpricedet)
        {
            int recordsAffected = 0;
            SqlCommand cmd = null;

            try
            {
                //Creating command object
                cmd = DataConnection.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "usp_UpdateCargoPrice";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@CargoPriceID", cpricedet.CargoPriceID);
                cmd.Parameters.AddWithValue("@Weight", cpricedet.Weight);
                cmd.Parameters.AddWithValue("@Price", cpricedet.Price);

                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                cmd.Connection.Close();
            }
            return recordsAffected;
        }

        //Function to delete CargoPrice record from database
        public static int Delete(int id)
        {
            int recordsAffected = 0;
            SqlCommand cmd = null;
            try
            {
                //Creating command object
                cmd = DataConnection.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "usp_DeleteCargoPrices";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@CargoPriceID", id);

                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                cmd.Connection.Close();
            }
            return recordsAffected;
        }

        //Function to search CargoPrice record based on id
        public static CargoPrice SearchByID(int id)
        {
            CargoPrice cpricedet = null;
            SqlCommand cmd = null;
            SqlDataReader dr = null;
            try
            {
                cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "usp_SearchCargoPrice";
                cmd.Parameters.AddWithValue("CargoPriceID", id);

                cmd.Connection.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    cpricedet = new CargoPrice();
                    dr.Read();
                    cpricedet.CargoPriceID = (int)dr["CargoPriceID"];
                    cpricedet.Weight = (decimal)dr["Weight"];
                    cpricedet.Price = (decimal)dr["Price"];

                }
                else
                {
                    throw new UserNotFoundException("Record not found");
                }

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                cmd.Connection.Close();
            }
            return cpricedet;
        }

        //Function to retrieve all CargoPrice record
        public static List<CargoPrice> SelectAll()
        {
            List<CargoPrice> cpricedetList = null;
            SqlCommand cmd = null;
            SqlDataReader dr = null;

            try
            {
                cmd = DataConnection.GenerateCommand();
                cmd.CommandText = "usp_DisplayCargoPrice";

                cmd.Connection.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    cpricedetList = new List<CargoPrice>();
                    while (dr.Read())
                    {
                        CargoPrice cpricedet = new CargoPrice();

                        cpricedet.CargoPriceID = (int)dr["CargoPriceID"];
                        cpricedet.Weight = (decimal)dr["Weight"];
                        cpricedet.Price = (decimal)dr["Price"];
                        cpricedetList.Add(cpricedet);
                    }
                }
                else
                    throw new UserNotFoundException("Record not available");

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                cmd.Connection.Close();
            }
            return cpricedetList;
        }
    }
}
