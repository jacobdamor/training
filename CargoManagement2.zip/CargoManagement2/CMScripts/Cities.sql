

ALTER PROC usp_InsertCities
(
	@CityName	VARCHAR(100),
	@State		VARCHAR(100)
)
AS
BEGIN
	INSERT INTO Cities(CityName, State)
	VALUES(@CityName, @State)
END;
GO

ALTER PROC usp_UpdateCities
(
	@CityName	VARCHAR(100),
	@State		VARCHAR(100)
)
AS
BEGIN
	UPDATE Cities
	SET  State = @State
	WHERE CityName = @CityName
END;
GO

ALTER PROC usp_DeleteCities
(
	@CityName	VARCHAR(100)
)
AS
BEGIN
	DELETE FROM Cities
	WHERE CityName = @CityName
END;
GO

ALTER PROC usp_SearchCities
(
	@CityName	VARCHAR(100)
)
AS
BEGIN
	SELECT * FROM Cities
	WHERE CityName = @CityName
END;
GO

ALTER PROC usp_DisplayCities
AS
BEGIN
	SELECT * FROM Cities
END;
GO