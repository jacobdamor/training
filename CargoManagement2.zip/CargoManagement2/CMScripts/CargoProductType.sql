
ALTER PROC usp_InsertCargoProductType
(
	@ProductType  VARCHAR(100)
)
AS
BEGIN
	INSERT INTO CargoProductType(ProductType)
	VALUES(@ProductType)
END;
GO

ALTER PROC usp_UpdateCargoProductType
(
	@TypeID		INT,
	@ProductType	VARCHAR(30)
)
AS
BEGIN
	UPDATE CargoProductType
	SET ProductType = @ProductType
	WHERE TypeID = @TypeID
END;
GO

ALTER PROC usp_DeleteCargoProductType
(
	@TypeID		INT
)
AS
BEGIN
	DELETE FROM CargoProductType
	WHERE TypeID = @TypeID
END;
GO

ALTER PROC usp_SearchCargoProductType
(
	@TypeID		INT
)
AS
BEGIN
	SELECT * FROM CargoProductType
	WHERE TypeID = @TypeID
END;
GO

ALTER PROC usp_DisplayCargoProductType
AS
BEGIN
	SELECT * FROM CargoProductType
END;
GO