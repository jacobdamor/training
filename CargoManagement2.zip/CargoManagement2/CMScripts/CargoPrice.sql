
ALTER PROC usp_InsertCargoPrice
(
	@Weight		DECIMAL (10, 3),
	@Price		DECIMAL (12, 2)
)
AS
BEGIN
	INSERT INTO CargoPrice(Weight, Price)
	VALUES(@Weight, @Price)
END;
GO

ALTER PROC usp_UpdateCargoPrice
(
	@CargoPriceID INT, 
	@Weight		DECIMAL (10, 3),
	@Price		DECIMAL (12, 2)
)
AS
BEGIN
	UPDATE CargoPrice
	SET Price = @Price,
		Weight = @Weight
	WHERE CargoPriceID = @CargoPriceID
END;
GO

ALTER PROC usp_DeleteCargoPrice
(
	@CargoPriceID INT
)
AS
BEGIN
	DELETE FROM CargoPrice
	WHERE CargoPriceID = @CargoPriceID
END;
GO

ALTER PROC usp_SearchCargoPrice
(
	@CargoPriceID INT
)
AS
BEGIN
	SELECT * FROM CargoPrice
	WHERE CargoPriceID = @CargoPriceID
END;
GO

ALTER PROC usp_DisplayCargoPrice
AS
BEGIN
	SELECT * FROM CargoPrice
END;
GO