
ALTER PROC usp_InsertRegister
(
	@UserName VARCHAR (100),
    @Password VARCHAR (100),
    @UserType VARCHAR (100),
    @PhoneNo  VARCHAR (100),
    @EmailId  VARCHAR (100),
    @ResID INT OUTPUT
)
AS
BEGIN
	INSERT INTO Register(UserName, Password, UserType, PhoneNo, EmailId)
	VALUES(@UserName, @Password, @UserType, @PhoneNo, @EmailId)
	SELECT @ResID = SCOPE_IDENTITY()
	RETURN
END;
GO

DECLARE @id INT
EXEC usp_InsertRegister "sdf", "sadgf", "Admin", "1231231233", "jackie@gmail.com", @id OUTPUT
SELECT @id

ALTER PROC usp_UpdateRegister
(
	@RegisterID INT,
	@UserName VARCHAR (100),
    @Password VARCHAR (100),
    @UserType VARCHAR (100),
    @PhoneNo  VARCHAR (100),
    @EmailId  VARCHAR (100)
)
AS
BEGIN
	UPDATE Register
	SET UserName = @UserName,
		Password = @Password,
		UserType = @UserType,
		PhoneNo = @PhoneNo,
		EmailId = @EmailId
	WHERE RegisterID = @RegisterID
END;
GO

ALTER PROC usp_DeleteRegister
(
	@RegisterID INT
)
AS
BEGIN
	DELETE FROM Register
	WHERE RegisterID = @RegisterID
END;
GO

ALTER PROC usp_SearchRegister
(
	@RegisterID INT
)
AS
BEGIN
	SELECT * FROM Register
	WHERE RegisterID = @RegisterID
END;
GO

ALTER PROC usp_DisplayRegister
AS
BEGIN
	SELECT * FROM Register
END;
GO


ALTER PROC usp_MatchRegister
(
	@UserName VARCHAR (100),
    @Password VARCHAR (100),
    @UserType VARCHAR (100)
)
AS
BEGIN
	SELECT * FROM Register
	WHERE UserName = @UserName
	AND Password = @Password
	AND UserType = @UserType
END;
GO