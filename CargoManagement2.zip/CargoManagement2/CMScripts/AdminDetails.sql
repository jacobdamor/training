ALTER PROC usp_InsertAdminDetails
(
    @AdminID INT,
    @Name       VARCHAR (100),
    @Address    VARCHAR (250),
    @City       VARCHAR (100)          
)
AS
BEGIN
	INSERT INTO AdminDetails(AdminID, Name, Address, City)
	VALUES(@AdminID, @Name, @Address, @City)
END;
GO

ALTER PROC usp_UpdateAdminDetails
(
	@AdminID INT,
    @Name       VARCHAR (100),
    @Address    VARCHAR (250),
    @City       VARCHAR (100) 
)
AS
BEGIN
	UPDATE AdminDetails
	SET Name = @Name,
		Address = @Address,
		City = @City
	WHERE AdminID = @AdminID
END;
GO

ALTER PROC usp_DeleteAdminDetails
(
	@AdminID          INT
)
AS
BEGIN
	DELETE FROM AdminDetails
	WHERE AdminID = @AdminID
END;
GO

ALTER PROC usp_SearchAdminDetails
(
	@AdminID          INT
)
AS
BEGIN
	SELECT * FROM AdminDetails
	WHERE AdminID = @AdminID
END;
GO

ALTER PROC usp_DisplayAdminDetails
AS
BEGIN
	SELECT * FROM AdminDetails
END;
GO