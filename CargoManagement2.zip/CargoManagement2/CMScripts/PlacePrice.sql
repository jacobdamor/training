

ALTER PROC usp_InsertPlacePrice
(
	@Source			VARCHAR (100),
	@Destination    VARCHAR (100),
	@Price			DECIMAL (12, 2)
)
AS
BEGIN
	INSERT INTO PlacePrice(Source, Destination, Price)
	VALUES(@Source, @Destination, @Price)
END;
GO

ALTER PROC usp_UpdatePlacePrice
(
	@Source			VARCHAR (100),
	@Destination    VARCHAR (100),
	@Price			DECIMAL (12, 2)
)
AS
BEGIN
	UPDATE PlacePrice
	SET 
	Price = @Price
	WHERE Source = @Source
	AND Destination = @Destination
END;
GO

ALTER PROC usp_DeletePlacePrice
(
	@Source			VARCHAR (100),
	@Destination    VARCHAR (100)
)
AS
BEGIN
	DELETE FROM PlacePrice
	WHERE Source = @Source
	AND Destination = @Destination
END;
GO

ALTER PROC usp_SearchPlacePrice
(
	@Source			VARCHAR (100),
	@Destination    VARCHAR (100)
)
AS
BEGIN
	SELECT * FROM PlacePrice
	WHERE Source = @Source
	AND Destination = @Destination
END;
GO

ALTER PROC usp_DisplayPlacePrice
AS
BEGIN
	SELECT * FROM PlacePrice
END;
GO