

ALTER PROC usp_InsertCargoOrderDetails
(
	@CargoOrderID            INT,
	@ProdID				INT,
	@UnitPrice			DECIMAL (10, 2),
	@Qty				INT,
	@Discount			DECIMAL (4, 3),
	@PaymentID			INT,
	@TotalAmount		DECIMAL (12, 2),
	@Source		    	VARCHAR(100),
	@Destination		VARCHAR(100),
	@DestinationAddr 	VARCHAR(250),
	@FlightNo			INT,
	@Status		    	VARCHAR(100)
)
AS
BEGIN
	INSERT INTO CargoOrderDetails(CargoOrderID, ProdID, UnitPrice, Qty, Discount, PaymentID, 
	TotalAmount, Source, Destination, DestinationAddr, FlightNo, Status)
	VALUES(@CargoOrderID, @ProdID, @UnitPrice, @Qty, @Discount, @PaymentID, 
	@TotalAmount, @Source, @Destination, @DestinationAddr, @FlightNo, @Status)
END;
GO

ALTER PROC usp_UpdateCargoOrderDetails
(
	@CargoID            INT,
	@CargoOrderID		INT,
	@ProdID				INT,
	@UnitPrice			DECIMAL (10, 2),
	@Qty				INT,
	@Discount			DECIMAL (4, 3),
	@PaymentID			INT,
	@TotalAmount		DECIMAL (12, 2),
	@Source		    	VARCHAR(100),
	@Destination		VARCHAR(100),
	@DestinationAddr 	VARCHAR(250),
	@FlightNo			INT,
	@Status		    	VARCHAR(100)
)
AS
BEGIN
	UPDATE CargoOrderDetails
	SET CargoOrderID = @CargoOrderID,
	ProdID = @ProdID,
	UnitPrice = @UnitPrice,
	Qty = @Qty,
	Discount = @Discount,
	PaymentID = @PaymentID,
	TotalAmount = @TotalAmount,
	Source = @Source,
	Destination = @Destination,
	DestinationAddr = @DestinationAddr,
	FlightNo = @FlightNo,
	Status = @Status
	WHERE CargoID = @CargoID
END;
GO

ALTER PROC usp_DeleteCargoOrderDetails
(
	@CargoID            INT
)
AS
BEGIN
	DELETE FROM CargoOrderDetails
	WHERE CargoID = @CargoID
END;
GO

ALTER PROC usp_SearchCargoOrderDetails
(
	@CargoID            INT
)
AS
BEGIN
	SELECT * FROM CargoOrderDetails
	WHERE CargoID = @CargoID
END;
GO

ALTER PROC usp_DisplayCargoOrderDetails
AS
BEGIN
	SELECT * FROM CargoOrderDetails
END;
GO