
ALTER PROC usp_InsertProductDetails
(
	@ProdName   VARCHAR (100),
	@TypeID	   	INT
)
AS
BEGIN
	INSERT INTO ProductDetails(ProdName, TypeID)
	VALUES(@ProdName, @TypeID)
END;
GO

ALTER PROC usp_UpdateProductDetails
(
	@ProdId		INT,
	@ProdName   VARCHAR (100),
	@TypeID	   	INT
)
AS
BEGIN
	UPDATE ProductDetails
	SET ProdName = @ProdName,
	TypeID = @TypeID
	WHERE ProdId = @ProdId
END;
GO

ALTER PROC usp_DeleteProductDetails
(
	@ProdId		INT
)
AS
BEGIN
	DELETE FROM ProductDetails
	WHERE ProdId = @ProdId
END;
GO

ALTER PROC usp_SearchProductDetails
(
	@ProdId		INT
)
AS
BEGIN
	SELECT * FROM ProductDetails
	WHERE ProdId = @ProdId
END;
GO

ALTER PROC usp_DisplayProductDetails
AS
BEGIN
	SELECT * FROM ProductDetails
END;
GO