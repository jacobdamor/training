ALTER PROC usp_InsertCancelRequest 
(
	@CustomerID          INT,
    @CancelRequestReason VARCHAR (250),
    @Date                DATE          
)
AS
BEGIN
	INSERT INTO CancelRequest(CustomerID, CancelRequestReason, Date)
	VALUES(@CustomerID, @CancelRequestReason, @Date)
END;
GO

ALTER PROC usp_UpdateCancelRequest
(
	@CancelRequestID 	 INT,	
	@CustomerID          INT,
    @CancelRequestReason VARCHAR (250),
    @Date                DATE 
)
AS
BEGIN
	UPDATE CancelRequest
	SET CustomerID = @CustomerID,
		CancelRequestReason = @CancelRequestReason,
		Date = @Date
	WHERE 	CancelRequestID = @CancelRequestID
END;
GO

ALTER PROC usp_DeleteCancelRequest
(
	@CancelRequestID          INT
)
AS
BEGIN
	DELETE FROM CancelRequest
	WHERE CancelRequestID = @CancelRequestID
END;
GO

ALTER PROC usp_SearchCancelRequest
(
	@CancelRequestID          INT
)
AS
BEGIN
	SELECT * FROM CancelRequest
	WHERE CancelRequestID = @CancelRequestID
END;
GO

ALTER PROC usp_DisplayCancelRequest
AS
BEGIN
	SELECT * FROM CancelRequest
END;
GO