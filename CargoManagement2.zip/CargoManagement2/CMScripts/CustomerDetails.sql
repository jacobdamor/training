ALTER PROC usp_InsertCustomerDetails
(
	@CustomerID INT,
    @Name       VARCHAR (100)= NULL,
    @Address    VARCHAR (250)= NULL,
    @City       VARCHAR (100)= NULL          
)
AS
BEGIN
	INSERT INTO CustomerDetails(CustomerID, Name, Address, City)
	VALUES(@CustomerID, @Name, @Address, @City )
END;
GO

ALTER PROC usp_UpdateCustomerDetails
(
	@CustomerID INT,
    @Name       VARCHAR (100)= NULL,
    @Address    VARCHAR (250)= NULL,
    @City       VARCHAR (100)= NULL
)
AS
BEGIN
	UPDATE CustomerDetails
	SET Name = @Name,
		Address = @Address,
		City = @City
	WHERE CustomerID = @CustomerID
END;
GO

ALTER PROC usp_DeleteCustomerDetails
(
	@CustomerID          INT
)
AS
BEGIN
	DELETE FROM CustomerDetails
	WHERE CustomerID = @CustomerID
END;
GO

ALTER PROC usp_SearchCustomerDetails
(
	@CustomerID          INT
)
AS
BEGIN
	SELECT * FROM CustomerDetails
	WHERE CustomerID = @CustomerID
END;
GO

ALTER PROC usp_DisplayCustomerDetails
AS
BEGIN
	SELECT * FROM CustomerDetails
END;
GO