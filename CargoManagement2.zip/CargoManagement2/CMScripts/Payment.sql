
ALTER PROC usp_InsertPayment
(
    @PayAccName			VARCHAR (100),
    @PayOrderID			INT,
    @PaymentDate        DATE,
    @Amount				DECIMAL (12, 2),
    @PaymentMethod		VARCHAR (100)          
)
AS
BEGIN
	INSERT INTO Payment(PayAccName, PayOrderID, PaymentDate, Amount, PaymentMethod)
	VALUES(@PayAccName, @PayOrderID, @PaymentDate, @Amount, @PaymentMethod)
END;
GO

ALTER PROC usp_UpdatePayment
(
	@PaymentID			INT,
    @PayAccName			VARCHAR (100),
    @PayOrderID			INT,
    @PaymentDate        DATE,
    @Amount				DECIMAL (12, 2),
    @PaymentMethod		VARCHAR (100)  
)
AS
BEGIN
	UPDATE Payment
	SET PayAccName    = @PayAccName,
		PayOrderID    = @PayOrderID,
		PaymentDate   = @PaymentDate,
		Amount        = @Amount,
		PaymentMethod = @PaymentMethod
	WHERE PaymentID = @PaymentID
END;
GO

ALTER PROC usp_DeletePayment
(
	@PaymentID          INT
)
AS
BEGIN
	DELETE FROM Payment
	WHERE PaymentID = @PaymentID
END;
GO

ALTER PROC usp_SearchPayment
(
	@PaymentID          INT
)
AS
BEGIN
	SELECT * FROM Payment
	WHERE PaymentID = @PaymentID
END;
GO

ALTER PROC usp_DisplayPayment
AS
BEGIN
	SELECT * FROM Payment
END;
GO