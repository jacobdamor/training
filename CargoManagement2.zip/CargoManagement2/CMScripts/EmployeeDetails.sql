ALTER PROC usp_InsertEmployeeDetails
(
    @EmployeeID INT,
    @Name       VARCHAR (100),
    @Address    VARCHAR (250),
    @City       VARCHAR (100)
)
AS
BEGIN
	INSERT INTO EmployeeDetails(EmployeeID, Name, Address, City)
	VALUES(@EmployeeID, @Name, @Address, @City)
END;
GO

ALTER PROC usp_UpdateEmployeeDetails
(
	@EmployeeID INT,
    @Name       VARCHAR (100),
    @Address    VARCHAR (250),
    @City       VARCHAR (100)
)
AS
BEGIN
	UPDATE EmployeeDetails
	SET Name = @Name,
		Address = @Address,
		City = @City
	WHERE EmployeeID = @EmployeeID
END;
GO

ALTER PROC usp_DeleteEmployeeDetails
(
	@EmployeeID          INT
)
AS
BEGIN
	DELETE FROM EmployeeDetails
	WHERE EmployeeID = @EmployeeID
END;
GO

ALTER PROC usp_SearchEmployeeDetails
(
	@EmployeeID          INT
)
AS
BEGIN
	SELECT * FROM EmployeeDetails
	WHERE EmployeeID = @EmployeeID
END;
GO

ALTER PROC usp_DisplayEmployeeDetails
AS
BEGIN
	SELECT * FROM EmployeeDetails
END;
GO