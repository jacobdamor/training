

ALTER PROC usp_InsertCargoOrder
(
	@OrderID		INT,
	@OrderDate      DATE,
	@DeleveryDate	DATE,
	@OrderPaymentID INT,
    @EmployeeID     INT,
    @CustomerID     INT
)
AS
BEGIN
	INSERT INTO CargoOrder(OrderID, OrderDate, DeleveryDate, OrderPaymentID, EmployeeID, CustomerID)
	VALUES(@OrderID, @OrderDate, @DeleveryDate, @OrderPaymentID, @EmployeeID, @CustomerID)
END;
GO

ALTER PROC usp_UpdateCargoOrder
(
	@OrderID		INT,
	@OrderDate      DATE,
	@DeleveryDate	DATE,
	@OrderPaymentID INT,
    @EmployeeID     INT,
    @CustomerID     INT
)
AS
BEGIN
	UPDATE CargoOrder
	SET OrderDate = @OrderDate,
	DeleveryDate = @DeleveryDate,
	OrderPaymentID = @OrderPaymentID,
	EmployeeID = @EmployeeID,
	CustomerID = @CustomerID
	WHERE OrderID = @OrderID
END;
GO

ALTER PROC usp_DeleteCargoOrder
(
	@OrderID		INT
)
AS
BEGIN
	DELETE FROM CargoOrder
	WHERE OrderID = @OrderID
END;
GO

ALTER PROC usp_SearchCargoOrder
(
	@OrderID		INT
)
AS
BEGIN
	SELECT * FROM CargoOrder
	WHERE OrderID = @OrderID
END;
GO

ALTER PROC usp_DisplayCargoOrder
AS
BEGIN
	SELECT * FROM CargoOrder
END;
GO