﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Threading.Tasks;

using CargoManagement_Entities;
using CargoManagement_Exceptions;
using CargoManagement_DAL;

namespace CargoManagement_BAL
{
    public class Authentication_BAL
    {
        public static bool AddCustomer(Register reg)
        {
            bool isSuccess = true;

            try
            {
                if (Validation.Register(reg))
                {
                    int id = Register_DAL.Insert(reg);
                    if (id > 0)
                    {
                        CustomerDetail custdet = new CustomerDetail();
                        custdet.CustomerID = id;
                        isSuccess = Customer_DAL.Insert(custdet) != 1 ? false : true;
                    }
                }
                else
                    throw new InvalidUserException("Please provide valid User Information");                
            }
            catch (InvalidUserException)
            {
                throw;
            }
            catch (SqlInsertionFailedException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }

            return isSuccess;
        }

        public static Register LoginUser(string userName, string password, string userType)
        {
            Register user = null;
            try
            {
                user = Register_DAL.matchCredentials(userName, password, userType);
                if (user == null)
                {
                    throw new UserNotFoundException();
                }

            }
            catch (SqlException)
            {
                throw;
            }
            catch (UserNotFoundException)
            {
                throw;
            }
            catch (Exception)
            {                
                throw;
            }
            return user;
        }
    }
}
