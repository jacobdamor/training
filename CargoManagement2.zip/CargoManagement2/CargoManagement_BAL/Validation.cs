﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using CargoManagement_Entities;
using CargoManagement_Exceptions;
using System.Text.RegularExpressions;

namespace CargoManagement_BAL
{
    internal class Validation
    {
        internal static bool Register(Register reg)
        {

            Boolean isValid = true;
            try
            {
                StringBuilder errorMessage = new StringBuilder();
                // Id
                if (reg.RegisterID < 0)
                {
                    isValid = false;
                    errorMessage.Append("User Id should be a positive number").Append(Environment.NewLine);
                }

                // Name
                Match matchName = Regex.Match(reg.UserName, "[^a-zA-z ]*");
                if (matchName.Success == false)
                {
                    isValid = false;
                    errorMessage.Append("Employee name should contains alphabets and space only").Append(Environment.NewLine);
                }

                // DOJ
                if (!(reg.UserType == "Admin" || reg.UserType == "Customer" || reg.UserType == "Employee"))
                {
                    isValid = false;
                    errorMessage.Append("User Type should be Admin, Customer or Employee").Append(Environment.NewLine);
                }

                if (!isValid)
                {
                    throw new InvalidUserException(errorMessage.ToString());
                }
            }
            catch (InvalidUserException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }

            return isValid;
        }
    }
}
