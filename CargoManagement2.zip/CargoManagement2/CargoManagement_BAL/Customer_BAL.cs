﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Threading.Tasks;

using CargoManagement_Entities;
using CargoManagement_DAL;
using CargoManagement_Exceptions;

namespace CargoManagement_BAL
{
    public class Customer_BAL
    {
        public static bool ModifyDetails(Register reg, CustomerDetail cust)
        {
            bool isSuccess = true;

            try
            {
                if (Validation.Register(reg) && Validation.Customer(cust))
                {
                    isSuccess = Register_DAL.Update(reg) != 1 ? false : true;
                    if (isSuccess)
                    {
                        isSuccess = Customer_DAL.Update(cust) != 1 ? false : true;
                    }
                }
                else
                    throw new InvalidUserException();
            }
            catch (InvalidUserException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                
                throw;
            }            

            return isSuccess;
        }
    }
}
