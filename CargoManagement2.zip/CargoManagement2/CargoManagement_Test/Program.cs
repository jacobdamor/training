﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using CargoManagement_Entities;
using CargoManagement_Exceptions;
using CargoManagement_BAL;

namespace CargoManagement_Test
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Register reg = new Register();
                reg.UserName = "jatin";
                reg.Password = "kajsgfd";
                reg.UserType = "Admin";
                reg.PhoneNo = "1234521";
                reg.EmailId = "asfddf2zdf";
                Authentication_BAL.AddCustomer(reg);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message + "\n" + ex.StackTrace);
            }
            Console.ReadKey();
        }
    }
}
