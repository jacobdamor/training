﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using CargoManagement_Entities;
using CargoManagement_BAL;
using CargoManagement_Exceptions;
using System.Diagnostics;
using System.Data.SqlClient;

namespace CargoManagement_PL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class StartUp : Window
    {
        public StartUp()
        {
            InitializeComponent();
            cb_UserType.SelectedIndex = 2;
        }

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (cb_UserType.SelectedIndex != 2)
            {
                txtBox_SignUpUsername.IsEnabled = false;
                txtBox_SignUpPassword.IsEnabled = false;
                txtBox_PhoneNo.IsEnabled = false;
                txtBox_EmailId.IsEnabled = false;
                txtBox_SignUpConfPassword.IsEnabled = false;
                btn_Signup.IsEnabled = false;
            }
            else
            {
                txtBox_SignUpUsername.IsEnabled = true;
                txtBox_SignUpPassword.IsEnabled = true;
                txtBox_PhoneNo.IsEnabled = true;
                txtBox_EmailId.IsEnabled = true;
                txtBox_SignUpConfPassword.IsEnabled = true;
                btn_Signup.IsEnabled = true;
            }
        }

        private void btn_Signup_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Register reg = new Register();
                reg.UserName = txtBox_SignUpUsername.Text;
                reg.PhoneNo = txtBox_PhoneNo.Text;
                reg.EmailId = txtBox_EmailId.Text;
                reg.UserType = "Customer";
                if (txtBox_SignUpPassword.Password.Equals(txtBox_SignUpConfPassword.Password))
                {
                    reg.Password = txtBox_SignUpPassword.Password;
                    if (Authentication_BAL.AddCustomer(reg))
                    {
                        lbl_Message.Foreground = Brushes.Green;
                        lbl_Message.Content = "Customer created";
                        lbl_Message.Foreground = Brushes.Red;
                        CustomerHome win = new CustomerHome(reg);
                        win.Show();
                        this.Close();
                    }
                }
                else
                {
                    lbl_Message.Content = "Passwords don't match";
                }
            }
            catch (SqlException ex)
            {
                switch (ex.Number)
                {
                    case 2627:  // Unique constraint error
                        lbl_Message.Content = "User already exists";
                        break;
                    default:
                        Debug.WriteLine(ex.Message + Environment.NewLine + ex.InnerException + Environment.NewLine + ex.StackTrace);
                        break;
                    //case 547:   // Constraint check violation
                    //case 2601:  // Duplicated key row error
                    //    // Constraint violation exception
                    //    throw new ConcurrencyException();   // A custom exception of yours for concurrency issues

                    //default:
                    //    // A custom exception of yours for other DB issues
                    //    throw new DatabaseAccessException(dbUpdateEx.Message, dbUpdateEx.InnerException);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message + Environment.NewLine + ex.InnerException + Environment.NewLine + ex.StackTrace);
            }
        }

        private void btn_Login_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string username = txtBox_SigninUsername.Text;
                string password = txtBox_SigninPassword.Password;
                string usertype = cb_UserType.SelectionBoxItem.ToString();

                Register user = Authentication_BAL.LoginUser(username, password, usertype);

                if (user != null)
                {
                    lbl_Message.Foreground = Brushes.Green;
                    lbl_Message.Content = "Valid User";
                    lbl_Message.Foreground = Brushes.Red;
                    switch(user.UserType)
                    {
                        case "Customer":
                            CustomerHome winC = new CustomerHome(user);
                            winC.Show();
                            this.Close();
                            break;
                        case "Employee":
                            EmployeeHome winE = new EmployeeHome();
                            winE.Show();
                            this.Close();
                            break;
                        case "Admin":
                            AdminHome winA = new AdminHome();
                            winA.Show();
                            this.Close();
                            break;
                    }                    
                }
            }
            catch (UserNotFoundException)
            {
                lbl_Message.Content = "InValid User";
                txtBox_SigninUsername.Text = String.Empty;
                txtBox_SignUpPassword.Password = String.Empty;
            }
            catch (SqlException ex)
            {
                switch (ex.Number)
                {
                    case 2627:  // Unique constraint error
                        lbl_Message.Content = "User already exists";
                        break;
                    default:
                        Debug.WriteLine(ex.Message + Environment.NewLine + ex.InnerException + Environment.NewLine + ex.StackTrace);
                        break;
                    //case 547:   // Constraint check violation
                    //case 2601:  // Duplicated key row error
                    //    // Constraint violation exception
                    //    throw new ConcurrencyException();   // A custom exception of yours for concurrency issues

                    //default:
                    //    // A custom exception of yours for other DB issues
                    //    throw new DatabaseAccessException(dbUpdateEx.Message, dbUpdateEx.InnerException);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message + Environment.NewLine + ex.InnerException + Environment.NewLine + ex.StackTrace);
            }         
        }
    }
}
