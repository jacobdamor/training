USE Cargo

-------------- TABLES FOR CARGO MANAGER SYSTEM -------------

CREATE TABLE Cities
(
	CityName VARCHAR(50) PRIMARY KEY NOT NULL,
	State VARCHAR(50) NOT NULL
)
GO

CREATE TABLE CargoProductType
(
	TypeID INT PRIMARY KEY IDENTITY(1,1),
	ProductType VARCHAR(50)
)
GO

CREATE TABLE PlacePrice
(
	Source VARCHAR(50) NOT NULL,
	Destination VARCHAR(50) NOT NULL,
	Price DECIMAL(12,2) NOT NULL,
	CONSTRAINT fk_PlacePrice_Source FOREIGN KEY(Source) REFERENCES Cities(CityName),
	CONSTRAINT fk_PlacePrice_Destination FOREIGN KEY(Destination) REFERENCES Cities(CityName),
	CONSTRAINT pk_PlacePrice PRIMARY KEY(Source,Destination)
)
GO

CREATE TABLE Register
(
	RegisterID INT IDENTITY(100000,1) PRIMARY KEY NOT NULL,
	UserName VARCHAR(50) UNIQUE NOT NULL,
	Password VARCHAR(50) UNIQUE NOT NULL,
	UserType VARCHAR(50) NOT NULL, 
	PhoneNo VARCHAR(13) NOT NULL,
	EmailId VARCHAR(60) NOT NULL,
	CONSTRAINT chkRegister_UserType CHECK (UserType IN ('Customer','Admin','Employee'))

)
GO

CREATE TABLE Payment
(
	PaymentID INT PRIMARY KEY NOT NULL,
	PayAccName VARCHAR(50) NOT NULL,
	PayOrderID INT NOT NULL,
	PaymentDate DATE NOT NULL,
	Amount DECIMAL(12,2) NOT NULL,
	PaymentMethod VARCHAR(50)
)
GO

CREATE TABLE CargoPrice
(
	CargoPriceID INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
	Weight DECIMAL(10,3) NOT NULL,
	Price DECIMAL(12,2)
)
GO

CREATE TABLE ProductDetails
(
	ProdID INT PRIMARY KEY NOT NULL,
	ProdName VARCHAR(50) NOT NULL,
	TypeID INT,
	CONSTRAINT fk_ProductDetails_TypeID FOREIGN KEY(TypeID) REFERENCES CargoProductType(TypeID)
)
GO

CREATE TABLE EmployeeDetails
(
	EmployeeID INT PRIMARY KEY NOT NULL,
	Name VARCHAR(50) NOT NULL,
	Address VARCHAR(200),
	City VARCHAR(50),
	CONSTRAINT fk_EmployeeDetails_City FOREIGN KEY(City) REFERENCES Cities(CityName),
	CONSTRAINT fk_EmployeeDetails_EmployeeID FOREIGN KEY(EmployeeID) REFERENCES Register(RegisterID)
)
GO

CREATE TABLE CustomerDetails
(
	CustomerID INT PRIMARY KEY NOT NULL,
	Name VARCHAR(50),
	Address VARCHAR(200),
	City VARCHAR(50),
	CONSTRAINT fk_CustomerDetails_City FOREIGN KEY(City) REFERENCES Cities(CityName),
	CONSTRAINT fk_CustomerDetails_CustomerID FOREIGN KEY(CustomerID) REFERENCES Register(RegisterID)
)
GO

CREATE TABLE AdminDetails
(
	AdminID INT PRIMARY KEY NOT NULL,
	Name VARCHAR(50) NOT NULL,
	Address VARCHAR(200),
	City VARCHAR(50),
	CONSTRAINT fk_AdminDetails_City FOREIGN KEY(City) REFERENCES Cities(CityName),
	CONSTRAINT fk_AdminDetails_AdminID FOREIGN KEY(AdminID) REFERENCES Register(RegisterID)
)
GO

CREATE TABLE CargoOrder
(
	OrderID INT PRIMARY KEY IDENTITY(100,1) NOT NULL,
	OrderDate DATE NOT NULL,
	DeleveryDate DATE NOT NULL,
	OrderPaymentID INT,
	EmployeeID INT,
	CustomerID INT,
	CONSTRAINT fk_CargoOrder_EmployeeID FOREIGN KEY(EmployeeID) REFERENCES EmployeeDetails(EmployeeID),
	CONSTRAINT fk_CargoOrder_CustomerID FOREIGN KEY(CustomerID) REFERENCES CustomerDetails(CustomerID)


)
GO

CREATE TABLE CancelRequest
(
	CancelRequestID INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
	CustomerID INT NOT NULL,
	CancelRequestReason VARCHAR(200),
	Date DATETIME,
	CONSTRAINT fk_CancelRequest_CustomerID FOREIGN KEY(CustomerID) REFERENCES CustomerDetails(CustomerID)
)
GO

CREATE TABLE CargoOrderDetails
(
	CargoID INT PRIMARY KEY IDENTITY(1,1) NOT NULL,
	CargoOrderID INT NOT NULL,
	ProdID INT NOT NULL,
	UnitPrice DECIMAL(10,2) NOT NULL,
	Qty INT NOT NULL,
	Discount DECIMAL(4,3) NOT NULL,
	PaymentID INT NOT NULL,
	TotalAmount DECIMAL(12,2) NOT NULL,
	Source VARCHAR(50) NOT NULL,
	Destination VARCHAR(50) NOT NULL,
	DestinationAddr VARCHAR(200) NOT NULL,
	FlightNo INT NOT NULL,
	Status VARCHAR(50),
	CONSTRAINT fk_CargoOrderDetails_Source FOREIGN KEY(Source,Destination) REFERENCES PlacePrice(Source,Destination),
	CONSTRAINT fk_CargoOrderDetails_ProdID FOREIGN KEY(ProdID) REFERENCES ProductDetails(ProdID),
	CONSTRAINT fk_CargoOrderDetails_CargoOrderID FOREIGN KEY(CargoOrderID) REFERENCES CargoOrder(OrderID),
	CONSTRAINT fk_CargoOrderDetails_PaymentID FOREIGN KEY(PaymentID) REFERENCES Payment(PaymentID)
)
GO



-------------------- Command to Drop the Tables-----------------------


DROP TABLE AdminDetails;
GO

DROP TABLE CargoOrderDetails;
GO

DROP TABLE CancelRequest;
GO

DROP TABLE CargoOrder;
GO

DROP TABLE CustomerDetails;
GO

DROP TABLE EmployeeDetails;
GO

DROP TABLE ProductDetails;
GO

DROP TABLE CargoPrice;
GO

DROP TABLE Payment;
GO

DROP TABLE Register;
GO

DROP TABLE PlacePrice;
GO

DROP TABLE CargoProductType;
GO

DROP TABLE Cities;
GO