﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Employee_DAL;
using Wpf_Entities;

namespace Employee_BAL
{
    public class EmployeeBAL
    {
        EmployeeDAL dal = new EmployeeDAL();
        public List<Employee> ListAll_BAL()
        {
            return dal.ListAll();
        }
        public bool Delete_BAL(int Id)
        {
            return dal.Delete(Id);
        }
        public bool Update_BAL(Employee emp)
        {
            return dal.Update(emp);
        }
        public bool Create_BAL(Employee emp)
        {
            return dal.Create(emp);
        }
    }
}
