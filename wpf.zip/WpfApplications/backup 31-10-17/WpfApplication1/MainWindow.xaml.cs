﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Wpf_Entities;
using Employee_BAL;

namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    /// Event handlig code
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Submit_Click(object sender, RoutedEventArgs e)
        {
            Employee emp = new Employee();
            emp.FullName =FullName.Text;
            emp.DOJ = DateTime.Parse(DOJ.Text); 
                //DateTime.Parse(DOJ.ToString());
            if(GenderF.IsChecked==true)
            {
                emp.Gender = GenderF.Content.ToString();
            }
            else if(GenderM.IsChecked==true)
            {
                emp.Gender = GenderM.Content.ToString();
            }
            emp.Department =(Department)Department.SelectedIndex;
            if (LanguagesKnown1.IsChecked == true)
            {
                emp.LanguagesKnown.Add(LanguagesKnown1.ToString());
            }
            if (LanguagesKnown2.IsChecked == true)
            {
                emp.LanguagesKnown.Add(LanguagesKnown2.ToString());
            }
            if (LanguagesKnown3.IsChecked == true)
            {
                emp.LanguagesKnown.Add(LanguagesKnown3.ToString());
            }
            
            emp.EMail = Email.Text;
            emp.PrimaryMobile = PrimaryMobile.Text;
            emp.PrimaryMobile = PrimaryMobile.Text;
            EmployeeBAL bal = new EmployeeBAL();
            bal.Create_BAL(emp);
        }

       

        private void State_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ListBoxItem i1 = (ListBoxItem)lbStates.SelectedValue;
            switch(i1.Content.ToString())
            {
                case "Uttar Pradesh" :
                    lbCities.Items.Clear();
                    lbCities.Items.Add("Allahabad");
                    lbCities.Items.Add("Kanpur");
                    lbCities.Items.Add("Lucknow");
                    break;
                case "Maharashtra" :
                    lbCities.Items.Clear();
                    lbCities.Items.Add("Mumbai");
                    lbCities.Items.Add("Pune");
                    lbCities.Items.Add("Nagpur");
                    break;
                case "Gujrat":
                    lbCities.Items.Clear();
                    lbCities.Items.Add("Ahemdabad");
                    lbCities.Items.Add("Surat");
                    lbCities.Items.Add("Baroda");
                    break;
                case "Tamilnadu":
                    lbCities.Items.Clear();
                    lbCities.Items.Add("Chennai");
                    lbCities.Items.Add("Coimbatore");
                    lbCities.Items.Add("Ooty");
                    break;
            }
        }
    }
}
