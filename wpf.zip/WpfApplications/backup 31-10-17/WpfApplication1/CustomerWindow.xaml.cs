﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for CustomerWindow.xaml
    /// </summary>
    public partial class CustomerWindow : Window
    {
        //Customer customer = null;
        List<Customer> customers = null;
        public CustomerWindow()
        {
            //InitializeComponent();
            ////customer = new Customer() { Id=5, FirstName = "Jacob", LastName = "Damor" };
            ////this.DataContext = customer;
            //customers = Customer.GetAllCustomers();
            //cbId.ItemSource = customers;
            //cbId.DisplayMemberPath = "Id";
            //cbId.SelectedValuePath = "Id";
        }

       
        //private void AddBTN_Click(object sender, RoutedEventArgs e)
        //{
        //    //Customer customer = new Customer();
        //    customer.Id = 13;
        //    customer.FirstName = "Tushar";
        //    customer.LastName = "deo";
        //}

        //private void ShowBTN_Click(object sender, RoutedEventArgs e)
        //{
        //    MessageBox.Show("Showing" + customer.FirstName+customer.LastName);
        //}
        private void cbId_SelectionChanged(object sender, RoutedEventArgs e)
        {
            //int id = int.Parse(cbId_SelectionChanged.SelectedValue.ToString());
            //this.DataContext = Customer.GetAllCustomers().Single(customers => customers.Id == id);
        }
    }
}
