﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication1
{
    public class Customer : INotifyPropertyChanged
    {
        private int id;

        public int Id
        {
            get { return id; }
            set 
            { 
                id = value;
                OnPropertyChanged("Id");
            }
        }
        private string firstName;

        public string FirstName
        {
            get { return firstName; }
            set 
            { 
                firstName = value;
                OnPropertyChanged("FirstName");
            }
        }

       
        private string lastName;

        public string LastName
        {
            get { return lastName; }
            set 
            {
                lastName = value;
                OnPropertyChanged("LastName");
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        private void OnPropertyChanged(string propertyName)
        {
            if(PropertyChanged!=null)
            {
                PropertyChanged.Invoke(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        public static List<Customer> GetAllCustomers()
        {
            List<Customer> emps=new List<Customer>
            {
                new Customer{Id = 1, FirstName="Rahul", LastName="Roy"},
                new Customer{Id = 2, FirstName="Jason", LastName="Bourne"},
                new Customer{Id = 3, FirstName="Matt", LastName="Damon"},

            };
            return emps;
        }
    }
}
