﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Wpf_Entities;

namespace Employee_DAL
{
    public class EmployeeDAL
    {
        static List<Employee> emps=new List<Employee>();
        public bool Create(Employee emp)
        {

            // ADO.NET CODE
            emps.Add(emp);
            return true;
        }
        
        public bool Update(Employee emp)
        {

            // ADO.NET CODE
            bool updated = false;
            foreach(var obj in emps)
            {
                if (obj.Id == emp.Id)
                {
                    obj.Id = emp.Id;
                    obj.FullName = emp.FullName;
                    obj.DOJ = emp.DOJ;
                    updated = true;
                }
            }
            return updated;
        }
        
        public bool Delete(int empId)
        {

            // ADO.NET CODE
            bool deleted = false;
            foreach (var obj in emps)
            {
                if (obj.Id == empId)
                {
                    deleted = true;
                    emps.Remove(obj);
                }
            }
            return deleted;
        }
        public List<Employee> ListAll()
        {

            // ADO.NET CODE
            List<Employee> empAll=new List<Employee>();
            foreach (var obj in emps)
            {
                empAll.Add(obj);
            }
            return empAll;
        }
    }
}
