﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Configuration;
//using WpfApplication1;
using Wpf_Entities;
using System.Data.SqlClient;

using Employee_BAL;

namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    /// Event handlig code
    public partial class MainWindow : Window
    {
        //private string ConfigurationManager;
        EmployeeBAL bal = null;
        Employee emp = null;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Submit_Click(object sender, RoutedEventArgs e)
        {
            string conString = System.Configuration.ConfigurationManager.ConnectionStrings["cn1"].ConnectionString;
            emp = new Employee();
            emp.FullName =FullName.Text;
            emp.DOJ = DateTime.Parse(DOJ.Text); 
                //DateTime.Parse(DOJ.ToString());
            if(GenderF.IsChecked==true)
            {
                emp.Gender = GenderF.Content.ToString();
            }
            else if(GenderM.IsChecked==true)
            {
                emp.Gender = GenderM.Content.ToString();
            }
            emp.Department =(Department)Department.SelectedIndex;
            StringBuilder sb = new StringBuilder();
            
            if (LanguagesKnown1.IsChecked == true)
            {
                sb.Append(LanguagesKnown1.Content.ToString());
            }
            if (LanguagesKnown2.IsChecked == true)
            {
                sb.Append(LanguagesKnown2.Content.ToString());
            }
            if (LanguagesKnown3.IsChecked == true)
            {
                sb.Append(LanguagesKnown3.Content.ToString());
            }

            emp.LanguagesKnown = sb.ToString();
            emp.EmpState = (State)lbStates.SelectedIndex;
            emp.EmpCity = (City)lbCities.SelectedIndex;
            emp.EMail = Email.Text;
            emp.PrimaryMobile = PrimaryMobile.Text;
            emp.AlternateMobile = AlternateMobile.Text;       
        }

       

        private void State_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ListBoxItem i1 = (ListBoxItem)lbStates.SelectedValue;
            switch(i1.Content.ToString())
            {
                case "UttarPradesh" :
                    lbCities.Items.Clear();
                    lbCities.Items.Add("Allahabad");
                    lbCities.Items.Add("Kanpur");
                    lbCities.Items.Add("Lucknow");
                    break;
                case "Maharashtra" :
                    lbCities.Items.Clear();
                    lbCities.Items.Add("Mumbai");
                    lbCities.Items.Add("Pune");
                    lbCities.Items.Add("Nagpur");
                    break;
                case "Gujrat":
                    lbCities.Items.Clear();
                    lbCities.Items.Add("Ahemdabad");
                    lbCities.Items.Add("Surat");
                    lbCities.Items.Add("Baroda");
                    break;
                case "Tamilnadu":
                    lbCities.Items.Clear();
                    lbCities.Items.Add("Chennai");
                    lbCities.Items.Add("Coimbatore");
                    lbCities.Items.Add("Ooty");
                    break;
            }
        }

        private void WindowLoaded(object sender, RoutedEventArgs e)
        {
            string conString = System.Configuration.ConfigurationManager.ConnectionStrings["cn1"].ConnectionString;
            EmployeeBAL bl = new EmployeeBAL(conString);
            List<Employee> empList = bl.ListAll_BAL();
            dg1.ItemsSource = empList;
        }

        private void Display_Click(object sender, RoutedEventArgs e)
        {
            string conString = System.Configuration.ConfigurationManager.ConnectionStrings["cnShowAll"].ConnectionString;
            EmployeeBAL bl = new EmployeeBAL(conString);
            List<Employee> empList = bl.ListAll_BAL();
            dg1.ItemsSource = empList;
        }

        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            string conString = System.Configuration.ConfigurationManager.ConnectionStrings["cnDelete"].ConnectionString;
            bal = new EmployeeBAL(conString);
            bal.Delete_BAL(emp);
        }

        private void Update_Click(object sender, RoutedEventArgs e)
        {

            string conString = System.Configuration.ConfigurationManager.ConnectionStrings["cnUpdate"].ConnectionString;
            bal = new EmployeeBAL(conString);
            bal.Update_BAL(emp);
        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {
            string conString = System.Configuration.ConfigurationManager.ConnectionStrings["cnAdd"].ConnectionString;
            bal = new EmployeeBAL(conString);
            bal.Create_BAL(emp);
        }
    }
}
