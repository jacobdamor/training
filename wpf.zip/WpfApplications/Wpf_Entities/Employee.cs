﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wpf_Entities
{
    public enum Department
    {
        Admin, HR, Operation, Finance
    }
    
    public enum State
    {
        UttarPradesh, Maharashtra, Gujrat, Tamilnadu
    }
   
    public enum City
    {
        Allahabad, Kanpur, Lucknow, Mumbai, Pune, Nagpur, Ahemdabad, Surat, Baroda, Chennai, Coimbatore, Ooty
    }
    public class Employee
    {
        //static int count;
        //static Employee ()
        //{
        //    count=0;
        //}

        public Employee()
        {
            //count++;
            //Id = count;
        }

        public int Id { get; set; }
        public string FullName { get; set; }
        public DateTime DOJ { get; set; }
        public string Gender { get; set; } 
        public Department Department { get; set; }
        public string LanguagesKnown { get; set; }
        public State EmpState { get; set; }
        public City EmpCity { get; set; }
        public string EMail { get; set; }
        public string PrimaryMobile { get; set; }
        public string AlternateMobile { get; set; }
    }
}
