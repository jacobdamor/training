﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using Wpf_Entities;

namespace Employee_DAL
{
    public class EmployeeDAL
    {

        SqlConnection cn = null;
        SqlCommand cmd = null;
        SqlDataReader dr = null;
        static List<Employee> emps = new List<Employee>();

        public EmployeeDAL(string conString)
        {
            cn = new SqlConnection(conString);
        }
        public bool Create(Employee emp)
        {
            // ADO.NET CODE
            
            cmd = new SqlCommand("Insert into Employee_138229 (FullName, DOJ, Gender, Department, LanguagesKnown, EmpState, EmpCity, EMail, PrimaryMobile, AlternateMobile) values ('"
                + emp.FullName + "', '" + emp.DOJ + "', '" + emp.Gender + "', '" + emp.Department + "', '" + emp.LanguagesKnown + "', '" + emp.EmpState + "', '" + emp.EmpCity + "', '" 
                + emp.EMail + "', '" + emp.PrimaryMobile + "', '" + emp.AlternateMobile + "' )", cn);
            cn.Open();

            //cmd.ExecuteNonQuery : insert, update, delete : integer
            //ExecuteReader : select DataReader object
            //ExecuteScalar : select which returns single cell value : object
            int no = cmd.ExecuteNonQuery();
            cn.Close();
            //emps.Add(emp);
            return true;
        }
        
        public bool Update(Employee emp)
        {

            // ADO.NET CODE
            //bool updated = false;
            //cmd.ExecuteNonQuery : insert, update, delete : integer
            //ExecuteReader : select DataReader object
            //ExecuteScalar : select which returns single cell value : object
            //foreach(var obj in emps)
            //{
            //    if (obj.Id == emp.Id)
            //    {
            //        obj.Id = emp.Id;
            //        obj.FullName = emp.FullName;
            //        obj.DOJ = emp.DOJ;
            //        updated = true;
            //    }
            //}
            //return updated;
            cmd = new SqlCommand("Update Employee_138229 set AlternateMobile = '" + emp.AlternateMobile + "' where  FullName = '" + emp.FullName + "'", cn);
            cn.Open();
            int no = cmd.ExecuteNonQuery();
            cn.Close();
            if (no == 1)
            {
                return true;
            }
            else
            {
                return false;
            }

           
           
        }

        public bool Delete(Employee emp)
        {

            // ADO.NET CODE
            //bool deleted = false;
            //foreach (var obj in emps)
            //{
            //    if (obj.Id == empId)
            //    {
            //        deleted = true;
            //        emps.Remove(obj);
            //    }
            //}
            //return deleted;
            cmd = new SqlCommand("Delete From Employee_138229 where FullName = '" + emp.FullName + "'", cn);
            cn.Open();
            int no = cmd.ExecuteNonQuery();
            cn.Close();
            if(no==1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public List<Employee> ListAll()
        {

            // ADO.NET CODE
            List<Employee> empAll=new List<Employee>();
            //foreach (var obj in emps)
            //{
            //    empAll.Add(obj);
            //}
            //return empAll;
            cmd = new SqlCommand("Select * From Employee_138229", cn);
            cn.Open();
            dr = cmd.ExecuteReader();
            while(dr.Read())
            {
                Employee emp = new Employee();
                emp.Id = Convert.ToInt32(dr["Id"]);
                emp.FullName = dr["FullName"].ToString();
                emp.DOJ = DateTime.Parse(dr["DOJ"].ToString());
                emp.Gender = dr["Gender"].ToString();
                emp.Department = (Department)Enum.Parse(typeof(Department), dr["Department"].ToString());
                emp.LanguagesKnown = dr["LanguagesKnown"].ToString();
                emp.EmpState = (State)Enum.Parse(typeof(State), dr["EmpState"].ToString());
                emp.EmpCity = (City)Enum.Parse(typeof(City), dr["EmpCity"].ToString());
                emp.EMail = dr["EMail"].ToString();
                emp.PrimaryMobile = dr["PrimaryMobile"].ToString();
                emp.AlternateMobile = dr["AlternateMobile"].ToString();
                empAll.Add(emp);
            }
            return empAll;
        }
    }
}
