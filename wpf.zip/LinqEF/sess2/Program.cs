﻿using System;
using System.Collections.Generic;
using System.Linq;//collection of extension methods
using System.Text;
using System.Threading.Tasks;

namespace sess2
{
    class Program
    {
        static void Main(string[] args)
        {
            int []numbers = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
            //var numberAsc = from num in numbers 
            //                orderby num descending
            //                select num;
            //foreach(var v in numberAsc)
            //{
            //    Console.WriteLine(v);
            //}


            var reverseNum = numbers.Reverse();
            foreach (var v in reverseNum)
            {
                Console.WriteLine(v);
            }


            //selectMany : get related data
        }
    }
}
