﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using sess6_ClassLib;
using System.Data.Entity;

namespace sess6_ConApp
{
    class Program
    {
        static void Main(string[] args)
        {
            var context = new Training_20Sep17_Pune_Batch_IEntities();
            //var allStudents = context.students.ToList();
            //foreach (var student in allStudents)
            //{
            //    Console.WriteLine("NAME : " + student.name + " BATCH : " + student.batch + " MARKS : " + student.matks + " BATCH NAME : " + student.batch1.name);
            //}
            //inner join
            //var studentDetails = from student in context.students
            //                     join b in context.batches
            //                     on student.batch equals b.id
            //                     select new
            //                     {
            //                         name = student.name,
            //                         batch = b,
            //                         RollNo=student.rollno,
            //                         Stream = b.stream
            //                     };
            //foreach (var record in studentDetails)
            //{
            //    Console.WriteLine("NAME : " + record.name + " is in " + record.batch.name);
            //}

            ////Right outer join
            //var studentDetails = from student in context.students.DefaultIfEmpty()
            //                     join b in context.batches
            //                     on student.batch equals b.id
            //                     select new
            //                     {
            //                         name = student.name,
            //                         batch = b,
            //                         RollNo = student.rollno,
            //                         Stream = b.stream
            //                     };
            //foreach (var record in studentDetails)
            //{
            //    Console.WriteLine("NAME : " + record.name + " is in " + record.batch.name);
            //}

            ////Right outer join
            //var studentDetails = from student in context.students
            //                     join b in context.batches.DefaultIfEmpty()
            //                     on student.batch equals b.id
            //                     select new
            //                     {
            //                         name = student.name,
            //                         batch = b,
            //                         RollNo = student.rollno,
            //                         Stream = b.stream
            //                     };
            //foreach (var record in studentDetails)
            //{
            //    Console.WriteLine("NAME : " + record.name + " is in " + record.batch.name);
            //}

            //Full outer join
            var studentDetails = from student in context.students.DefaultIfEmpty()
                                 join b in context.batches.DefaultIfEmpty()
                                 on student.batch equals b.id
                                 select new
                                 {
                                     name = student.name,
                                     batch = b,
                                     RollNo = student.rollno,
                                     Stream = b.stream
                                 };
            foreach (var record in studentDetails)
            {
                Console.WriteLine("NAME : " + record.name + " is in " + record.batch.name);
            }
        }
    }
}
