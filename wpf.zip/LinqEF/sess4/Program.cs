﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sess4
{  class Student
    {
        public string  Name { get; set; }
        public string  Stream { get; set; }
        public int Marks { get; set; }
    }
    class Program
    {
        static void Main(string[] args)
        {
            var students = new List<Student>
            {
                new Student
                {
                    Name = "abc",
                    Stream="cse",
                    Marks =70
                },
                new Student
                {
                    Name = "ijk",
                    Stream="ece",
                    Marks =80
                },
                new Student
                {
                    Name = "pqr",
                    Stream="cse",
                    Marks =90
                },
                new Student
                {
                    Name = "xyz",
                    Stream="ece",
                    Marks =50
                },
                 new Student
                {
                    Name = "rst",
                    Stream="ece",
                    Marks =80
                }
            };
            var groupData = from student in students
                            group student by student.Stream
                                into group1
                                select new  //internally creating a class
                                {
                                    key = group1.Key,
                                    records = group1.ToList()
                                };
            foreach (var groupdata in groupData)
            {
                Console.WriteLine(groupdata.key + " Students");
                Console.WriteLine("No of students {0}",groupdata.records.Count);
                foreach(var record in groupdata.records)
                {
                    Console.WriteLine(record.Name);
                }

                Console.WriteLine();
            }

            
        }
    }
}
