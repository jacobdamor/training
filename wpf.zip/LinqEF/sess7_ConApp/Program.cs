﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sess7_ConApp
{
    class Program
    {
        static void Main(string[] args)
        {
            var context = new CollegeDataContext1_138229();
            Batch_138229 batch1 = new Batch_138229();
            batch1.Name = "IT Batch";
            batch1.Stream = "IT";

            Batch_138229 batch2 = new Batch_138229();
            batch2.Name = "Telecom Batch";
            batch2.Stream = "Telecom";

            Batch_138229 batch3 = new Batch_138229();
            batch3.Name = "IT Batch";
            batch3.Stream = "IT";

            Batch_138229 batch4 = new Batch_138229();
            batch3.Name = "TR Batch";
            batch3.Stream = "TR";

            context.Entry<Batch_138229>(batch1).State = EntityState.Added;
            context.Entry<Batch_138229>(batch2).State = EntityState.Added;
            context.Entry<Batch_138229>(batch3).State = EntityState.Added;

            context.SaveChanges();

            var allBatches = context.Batch;
            foreach(var batch in allBatches)
            {
                Console.WriteLine(batch.Stream);
            }
        }
    }
}
