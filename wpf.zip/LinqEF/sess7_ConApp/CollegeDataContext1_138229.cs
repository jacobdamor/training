﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;

namespace sess7_ConApp
{
    class CollegeDataContext1_138229 : DbContext
    {
        public DbSet<Batch_138229> Batch  { get; set; }
        public DbSet<Student_138229> Student { get; set; }
    }
}
