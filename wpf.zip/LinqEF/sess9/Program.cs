﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sess9_wpf
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
