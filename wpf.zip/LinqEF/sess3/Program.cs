﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sess3
{
    class Student
    {
        public int RollNo { get; set; }
        public string  Name { get; set; }
        public int Marks { get; set; }
    }
    class Program
    {
        static void Main(string[] args)
        {
            var students=new List<Student>
            {
                new Student
                {
                    Name = "abc",
                    RollNo = 1,
                    Marks = 70
                },
                new Student
                {
                    Name = "ijk",
                    RollNo = 2,
                    Marks = 80
                },
                new Student
                {
                    Name = "pqr",
                    RollNo = 3,
                    Marks = 90
                },
                  new Student
                {
                    Name = "xyz",
                    RollNo = 4,
                    Marks = 70
                }
            };
            //var studentRanks = from student in students
            //                   orderby student.Marks descending 
            //                   select student;
            //foreach (var v in studentRanks)
            //{
            //    Console.WriteLine(v.Name + " Scored : " + v.Marks);
            //}

            //tieBreaker
            var studentRanksMethod = students.OrderByDescending(student => student.Marks).ThenByDescending(student => student.Name);

            foreach (var v in studentRanksMethod)
            {
                Console.WriteLine(v.Name+" Scored : "+v.Marks);
            }

        }
    }
}
