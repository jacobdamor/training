﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Linq
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] names = { "jack", "tom", "raul", "zidan", "rosiscky", "ronaldo", "messi" };
            //var nameQuery = from name in names select name; //just in time load happens : Delayed loading : preferred
            //names[3] = "changed";
            //foreach (var n in nameQuery)
            //{
            //    Console.WriteLine(n);
            //}

            //var nameQuery = (from name in names select name).ToList(); //eager loading
            //names[3] = "changed";
            //foreach(var n in nameQuery)
            //{
            //    Console.WriteLine(n);
            //}

            //var nameQuery = (from name in names where name.StartsWith("r") select name).ToList(); // introducing where condition
            //foreach (var n in nameQuery)
            //{
            //    Console.WriteLine(n);
            //}

            var nameQuery = (from name in names select name).ToList(); // introducing where condition
            foreach (var n in nameQuery)
            {
                Console.WriteLine(n);
            }
        }
    }
}
