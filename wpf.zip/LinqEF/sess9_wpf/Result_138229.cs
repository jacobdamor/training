﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace sess9_wpf
{
    public class Result_138229
    {
        public int Id { get; set; }
        //[ForeignKey("StudentRollNo")]
        public int RollNo { get; set; }
        public int sub1 { get; set; }
        public int sub2 { get; set; }
    }
}
