﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;

namespace sess9_wpf
{
    public class SchoolDataContext_138229:DbContext
    {
        public DbSet<Student_138229> Student_138229 { get; set; }
        public DbSet<Result_138229> Result_138229 { get; set; }
    }
}
