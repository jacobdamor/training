
-- --------------------------------------------------
-- Entity Designer DDL Script for SQL Server 2005, 2008, 2012 and Azure
-- --------------------------------------------------
-- Date Created: 11/03/2017 12:37:26
-- Generated from EDMX file: D:\Users\jdamor\Desktop\module_2_exam\LinqEF\sess8\Model1.edmx
-- --------------------------------------------------

SET QUOTED_IDENTIFIER OFF;
GO
USE [Training_20Sep17_Pune_Batch_I];
GO
IF SCHEMA_ID(N'dbo') IS NULL EXECUTE(N'CREATE SCHEMA [dbo]');
GO

-- --------------------------------------------------
-- Dropping existing FOREIGN KEY constraints
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[FK_Employee_138229Project_138229]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Project_138229] DROP CONSTRAINT [FK_Employee_138229Project_138229];
GO
IF OBJECT_ID(N'[dbo].[FK_Customer_138229Project_138229]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Project_138229] DROP CONSTRAINT [FK_Customer_138229Project_138229];
GO

-- --------------------------------------------------
-- Dropping existing tables
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[Project_138229]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Project_138229];
GO
IF OBJECT_ID(N'[dbo].[Employee_138229]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Employee_138229];
GO
IF OBJECT_ID(N'[dbo].[Customer_138229]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Customer_138229];
GO

-- --------------------------------------------------
-- Creating all tables
-- --------------------------------------------------

-- Creating table 'Project_138229'
CREATE TABLE [dbo].[Project_138229] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Name] nvarchar(50)  NOT NULL,
    [Employee_138229Id] int  NOT NULL,
    [CustomerId] int  NOT NULL,
    [Customer_138229Id] int  NOT NULL
);
GO

-- Creating table 'Employee_138229'
CREATE TABLE [dbo].[Employee_138229] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Name] nvarchar(50)  NOT NULL,
    [ProjectId] nvarchar(max)  NOT NULL,
    [Address_Line1] varchar(50)  NOT NULL,
    [Address_Line2] varchar(50)  NOT NULL
);
GO

-- Creating table 'Customer_138229'
CREATE TABLE [dbo].[Customer_138229] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Name] varchar(50)  NOT NULL,
    [Location] varchar(50)  NOT NULL
);
GO

-- --------------------------------------------------
-- Creating all PRIMARY KEY constraints
-- --------------------------------------------------

-- Creating primary key on [Id] in table 'Project_138229'
ALTER TABLE [dbo].[Project_138229]
ADD CONSTRAINT [PK_Project_138229]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'Employee_138229'
ALTER TABLE [dbo].[Employee_138229]
ADD CONSTRAINT [PK_Employee_138229]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'Customer_138229'
ALTER TABLE [dbo].[Customer_138229]
ADD CONSTRAINT [PK_Customer_138229]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- --------------------------------------------------
-- Creating all FOREIGN KEY constraints
-- --------------------------------------------------

-- Creating foreign key on [Employee_138229Id] in table 'Project_138229'
ALTER TABLE [dbo].[Project_138229]
ADD CONSTRAINT [FK_Employee_138229Project_138229]
    FOREIGN KEY ([Employee_138229Id])
    REFERENCES [dbo].[Employee_138229]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Employee_138229Project_138229'
CREATE INDEX [IX_FK_Employee_138229Project_138229]
ON [dbo].[Project_138229]
    ([Employee_138229Id]);
GO

-- Creating foreign key on [Customer_138229Id] in table 'Project_138229'
ALTER TABLE [dbo].[Project_138229]
ADD CONSTRAINT [FK_Customer_138229Project_138229]
    FOREIGN KEY ([Customer_138229Id])
    REFERENCES [dbo].[Customer_138229]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Customer_138229Project_138229'
CREATE INDEX [IX_FK_Customer_138229Project_138229]
ON [dbo].[Project_138229]
    ([Customer_138229Id]);
GO

-- --------------------------------------------------
-- Script has ended
-- --------------------------------------------------