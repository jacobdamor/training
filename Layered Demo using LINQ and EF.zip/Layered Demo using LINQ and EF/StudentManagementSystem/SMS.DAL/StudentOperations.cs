﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS.Entity;
using SMS.Exception;
using System.Data.Entity;

namespace SMS.DAL
{
    public class StudentOperations
    {
        static TrainingEntities context = new TrainingEntities();

        public static int AddStudent(Student_master stud)
        {
            int records = 0;

            try 
            {
                context.Student_master.Add(stud);

                records = context.SaveChanges();
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return records;
        }

        public static int UpdateStudent(Student_master stud)
        {
            int records = 0;

            try
            {
                var students = (from s in context.Student_master
                               where (s.Stud_Code == stud.Stud_Code)
                               select s).FirstOrDefault();

                if(students != null)
                {
                    students.Stud_Name = stud.Stud_Name;
                    students.Dept_Code = stud.Dept_Code;
                    students.Stud_Dob = stud.Stud_Dob;
                    students.Address = stud.Address;
                    students.Stud_Year = stud.Stud_Year;

                    records = context.SaveChanges();
                }
                else
                    throw new Student_masterException("Record not found for updation");
            }
            catch(Student_masterException ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }

            return records;
        }

        public static int DeleteStudent(int scode)
        {
            int records = 0;

            try 
            {
                var students = (from s in context.Student_master
                                where s.Stud_Code == scode
                                select s).FirstOrDefault();

                if (students != null)
                {
                    context.Student_master.Remove(students);
                    records = context.SaveChanges();
                }
                else
                    throw new Student_masterException("Record not found for deletion");
            }
            catch (Student_masterException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return records;
        }

        public static Student_master SearchStudent(int scode)
        {
            Student_master stud = null;

            try 
            {
                stud = (from s in context.Student_master
                        where s.Stud_Code == scode
                        select s).FirstOrDefault();
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return stud;
        }

        public static List<Student_master> GetAllStudent()
        {
            List<Student_master> studList = null;

            try 
            {
                studList = context.Student_master.ToList<Student_master>();
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return studList;
        }
    }
}
