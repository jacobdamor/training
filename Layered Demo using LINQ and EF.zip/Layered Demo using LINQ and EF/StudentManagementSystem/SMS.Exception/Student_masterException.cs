﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.Exception
{
    public class Student_masterException : ApplicationException
    {
        public Student_masterException()
            : base()
        { }

        public Student_masterException(string message)
            : base(message)
        { }
    }
}
